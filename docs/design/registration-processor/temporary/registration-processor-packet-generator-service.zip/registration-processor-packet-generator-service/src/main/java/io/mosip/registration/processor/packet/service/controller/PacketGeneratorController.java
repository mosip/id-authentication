package io.mosip.registration.processor.packet.service.controller;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.mosip.kernel.core.util.DateUtils;
import io.mosip.registration.processor.core.token.validation.TokenValidator;
import io.mosip.registration.processor.core.util.DigitalSignatureUtility;
import io.mosip.registration.processor.packet.manager.decryptor.Decryptor;
import io.mosip.registration.processor.packet.service.PacketGeneratorService;
import io.mosip.registration.processor.packet.service.dto.PacketGeneratorResDto;
import io.mosip.registration.processor.packet.service.dto.PacketGeneratorResponseDto;
import io.mosip.registration.processor.packet.service.exception.RegBaseCheckedException;
import io.mosip.registration.processor.packet.service.util.encryptor.EncryptorUtil;
import io.mosip.registration.processor.packet.upload.service.impl.SyncUploadEncryptionServiceImpl;
import io.mosip.registration.processor.packet.upload.service.request.validator.PacketGeneratorRequestValidator;
import io.mosip.registration.processor.status.sync.response.dto.RegSyncResponseDTO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Class PacketGeneratorController.
 * 
 * @author Sowmya
 */
@RefreshScope
@RestController
@Api(tags = "PacketGenerator")
public class PacketGeneratorController {

	/** The packet generator service. */
	@Autowired
	private PacketGeneratorService packetGeneratorService;

	/** The env. */
	@Autowired
	private Environment env;

	/** Token validator class */
	@Autowired
	TokenValidator tokenValidator;

	private static final String RESPONSE_SIGNATURE = "Response-Signature";

	/** The Constant REG_PACKET_GENERATOR_SERVICE_ID. */
	private static final String REG_PACKET_GENERATOR_SERVICE_ID = "mosip.registration.processor.registration.packetgenerator.id";

	/** The Constant REG_PACKET_GENERATOR_APPLICATION_VERSION. */
	private static final String REG_PACKET_GENERATOR_APPLICATION_VERSION = "mosip.registration.processor.application.version";

	/** The Constant DATETIME_PATTERN. */
	private static final String DATETIME_PATTERN = "mosip.registration.processor.datetime.pattern";

	/** The validator. */
	@Autowired
	private PacketGeneratorRequestValidator validator;

	@Value("${registration.processor.signature.isEnabled}")
	Boolean isEnabled;

	@Autowired
	DigitalSignatureUtility digitalSignatureUtility;

	@Autowired
	private Decryptor decryptor;

	@Autowired
	private EncryptorUtil encryptor;

	@Autowired
	private SyncUploadEncryptionServiceImpl syncPacket;

	/**
	 * Gets the status.
	 *
	 * @param packerGeneratorRequestDto
	 *            the packer generator request dto
	 * @param errors
	 *            the errors
	 * @return the status
	 * @throws RegBaseCheckedException
	 * @throws IOException
	 */
	@PostMapping(path = "/decryptPacket", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	@ApiOperation(value = "Get the status of packet", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Error Occured"),
			@ApiResponse(code = 400, message = "Unable to fetch the status "),
			@ApiResponse(code = 500, message = "Internal Server Error") })
	public ResponseEntity<Object> getStatus(
			@RequestParam(value = "packet", required = true) MultipartFile encryptedFile,
			@CookieValue(value = "Authorization", required = true) String token)
			throws RegBaseCheckedException, IOException {
		tokenValidator.validate("Authorization=" + token, "packetgenerator");

		try {
			String regId = FilenameUtils.getBaseName(encryptedFile.getOriginalFilename());
			InputStream encryptPacketStream = new BufferedInputStream(encryptedFile.getInputStream());
			InputStream decryptStream = decryptor.decrypt(encryptPacketStream, regId);
			InputStreamResource resource = new InputStreamResource(decryptStream);

			return ResponseEntity.ok().contentType(MediaType.parseMediaType("application/zip"))
					.header("Content-Disposition", "attachment; filename=\"" + regId + ".zip\"")
					.body((Object) resource);
		} catch (Exception e) {
			return ResponseEntity.ok().body("decryption error : " + ExceptionUtils.getStackTrace(e));

		}
	}

	@PostMapping(path = "/encryptPacket", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	@ApiOperation(value = "Get the status of packet", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Error Occured"),
			@ApiResponse(code = 400, message = "Unable to fetch the status "),
			@ApiResponse(code = 500, message = "Internal Server Error") })
	public ResponseEntity<Object> encryptPacket(
			@RequestParam(value = "packet", required = true) MultipartFile encryptedFile,
			@CookieValue(value = "Authorization", required = true) String token)
			throws RegBaseCheckedException, IOException {
		tokenValidator.validate("Authorization=" + token, "packetgenerator");

		try {
			String regId = FilenameUtils.getBaseName(encryptedFile.getOriginalFilename());
			InputStream encryptPacketStream = new BufferedInputStream(encryptedFile.getInputStream());
			byte[] bytes = IOUtils.toByteArray(encryptPacketStream);

			String packetCreatedDateTime = regId.substring(regId.length() - 14);
			String formattedDate = packetCreatedDateTime.substring(0, 8) + "T"
					+ packetCreatedDateTime.substring(packetCreatedDateTime.length() - 6);

			LocalDateTime ldt = LocalDateTime.parse(formattedDate, DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss"));

			String str = encryptor.encrypt(bytes, regId, ldt.toString() + ".000Z");
			InputStream encryptedStream = IOUtils.toInputStream(str);
			InputStreamResource resource = new InputStreamResource(encryptedStream);

			return ResponseEntity.ok().contentType(MediaType.parseMediaType("application/zip"))
					.header("Content-Disposition", "attachment; filename=\"" + regId + ".zip\"")
					.body((Object) resource);
		} catch (Exception e) {
			return ResponseEntity.ok().body("encryption failed" + ExceptionUtils.getStackTrace(e));

		}
	}

	@PostMapping(path = "/syncPacket", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	@ApiOperation(value = "Get the status of packet", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Error Occured"),
			@ApiResponse(code = 400, message = "Unable to fetch the status "),
			@ApiResponse(code = 500, message = "Internal Server Error") })
	public ResponseEntity<Object> syncPacket(
			@RequestParam(value = "packet", required = true) MultipartFile encryptedFile,
			@RequestParam(value = "regType", required = true) String regType,
			@CookieValue(value = "Authorization", required = true) String token)
			throws RegBaseCheckedException, IOException {
		tokenValidator.validate("Authorization=" + token, "packetgenerator");

		try {
			String regId = FilenameUtils.getBaseName(encryptedFile.getOriginalFilename());
			InputStream encryptPacketStream = new BufferedInputStream(encryptedFile.getInputStream());
			byte[] bytes = IOUtils.toByteArray(encryptPacketStream);

			String packetCreatedDateTime = regId.substring(regId.length() - 14);
			String formattedDate = packetCreatedDateTime.substring(0, 8) + "T"
					+ packetCreatedDateTime.substring(packetCreatedDateTime.length() - 6);

			LocalDateTime ldt = LocalDateTime.parse(formattedDate, DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss"));
			RegSyncResponseDTO regSyncDto = syncPacket.packetSync(regId, regType.toUpperCase(), bytes,
					ldt.toString() + ".000Z");
			if (regSyncDto != null && regSyncDto.getErrors() == null) {
				return ResponseEntity.ok().body("Synced successfully");

			} else {
				return ResponseEntity.ok().body("sync failed");

			}

		} catch (Exception e) {
			return ResponseEntity.ok().body("Sync error : " + ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 * Builds the packet generator response.
	 *
	 * @param packerGeneratorResDto
	 *            the packer generator res dto
	 * @return the string
	 */
	public String buildPacketGeneratorResponse(PacketGeneratorResDto packerGeneratorResDto) {

		PacketGeneratorResponseDto response = new PacketGeneratorResponseDto();
		if (Objects.isNull(response.getId())) {
			response.setId(env.getProperty(REG_PACKET_GENERATOR_SERVICE_ID));
		}
		response.setResponsetime(DateUtils.getUTCCurrentDateTimeString(env.getProperty(DATETIME_PATTERN)));
		response.setVersion(env.getProperty(REG_PACKET_GENERATOR_APPLICATION_VERSION));
		response.setResponse(null);
		response.setErrors(null);
		Gson gson = new GsonBuilder().create();
		return gson.toJson(response);
	}
}
