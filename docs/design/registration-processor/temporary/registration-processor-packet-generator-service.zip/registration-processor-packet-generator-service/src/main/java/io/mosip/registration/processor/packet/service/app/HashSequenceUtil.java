package io.mosip.registration.processor.packet.service.app;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.hibernate.validator.internal.util.privilegedactions.GetClassLoader;
import org.springframework.test.util.ReflectionTestUtils;

import io.mosip.kernel.core.util.HMACUtils;

public class HashSequenceUtil {

	public HashSequenceUtil() {
		super();
		
	}
	
	public String getPacketHashSequence(File file) {
		InputStream encryptedInputStream;
		byte[] isbytearray;
		String hashSequence="";
		try {
			encryptedInputStream = new FileInputStream(file.getAbsolutePath());
			isbytearray = IOUtils.toByteArray(encryptedInputStream);
			HMACUtils.update(isbytearray);
			 hashSequence = HMACUtils.digestAsPlainText(HMACUtils.updatedHash());
			return hashSequence;
		} catch (FileNotFoundException e1) {
			
		
		}catch (IOException e) {
		
		}
	     return hashSequence;
	}
   public static long getPacketSize(File file) {
	   System.out.println(file.length());
	  return file.length();
	 
	
  }
   
   public static void main(String args[]) throws UnsupportedEncodingException {
//	   HashSequenceUtil test = new HashSequenceUtil();
//	 /*  String fileName = "C/Users/M1047487.MINDTREE/Desktop/10006100060000120190523114433.zip";
//	   File file = new File(fileName);*/
//	   File file = new File("D:\\git\\0.12.0_packets\\ranjitha\\NewlyEncrypted\\10006100520001120190618060459.zip");
//	   String result = test.getPacketHashSequence(file);
//	 //  long result1 = test.getPacketSize(file);
//	   System.out.println(result);
//	   
//	   getPacketSize(file);
//	   char b = 'I';
//	   String base64encodedString = Base64.getEncoder().encodeToString(
//	            "BW".getBytes("utf-8"));
//	   System.out.println(b+" double "+base64encodedString+"");
//	   char a = 228;
//	   System.out.println(a);
	   String str = "Interplanetary$";
	   
	   Map<Integer,Character> hMap = new HashMap<>();
	   hMap.put(0, 'A');
	   hMap.put(1, 'B');
	   hMap.put(2, 'C');
	   hMap.put(3, 'D');
	   hMap.put(4, 'E');
	   hMap.put(5, 'F');
	   hMap.put(6, 'G');
	   hMap.put(7, 'H');
	   hMap.put(8, 'I');
	   hMap.put(9, 'J');
	   hMap.put(10, 'K');
	   hMap.put(11, 'L');
	   hMap.put(12, 'M');
	   hMap.put(13, 'N');
	   hMap.put(14, 'O');
	   hMap.put(15, 'P');	
	   hMap.put(16, 'Q');
	   hMap.put(17, 'R');
	   hMap.put(18, 'S');
	   hMap.put(19, 'T');
	   hMap.put(20, 'U');
	   hMap.put(21, 'V');
	   hMap.put(22, 'W');
	   hMap.put(23, 'X');
	   hMap.put(24, 'Y');
	   hMap.put(25, 'Z');
	   
	   hMap.put(26, 'a');
	   hMap.put(27, 'b');
	   hMap.put(28, 'c');
	   hMap.put(29, 'd');
	   hMap.put(30, 'e');
	   hMap.put(31, 'f');
	   hMap.put(32, 'g');
	   hMap.put(33, 'h');
	   hMap.put(34, 'i');
	   hMap.put(35, 'j');
	   hMap.put(36, 'k');
	   hMap.put(37, 'l');
	   hMap.put(38, 'm');
	   hMap.put(39, 'n');
	   hMap.put(40, 'o');
	   hMap.put(41, 'p');	
	   hMap.put(42, 'q');
	   hMap.put(43, 'r');
	   hMap.put(44, 's');
	   hMap.put(45, 't');
	   hMap.put(46, 'u');
	   hMap.put(47, 'v');
	   hMap.put(48, 'w');
	   hMap.put(49, 'x');
	   hMap.put(50, 'y');
	   hMap.put(51, 'z');
	   
	   hMap.put(52, '0');
	   hMap.put(53, '1');
	   hMap.put(54, '2');
	   hMap.put(55, '3');
	   hMap.put(56, '4');
	   hMap.put(57, '5');
	   hMap.put(58, '6');
	   hMap.put(59, '7');
	   hMap.put(60, '8');
	   hMap.put(61, '9');
	   
	   
   }
}
