<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1540536629959" ID="ID_807090370" MODIFIED="1540536723684" TEXT="Registration Packet Status Reader">
<node COLOR="#66cc00" CREATED="1540556429125" ID="ID_307309965" LINK="https://mosipid.atlassian.net/browse/MOS-1014" MODIFIED="1540817655134" POSITION="right" TEXT="MOS-1014">
<node COLOR="#66cc00" CREATED="1540537408694" HGAP="14" ID="ID_1164511610" MODIFIED="1540817575209" TEXT="Client registration officer to manually sync Registration packet status from server to client" VSHIFT="18">
<node COLOR="#66cc00" CREATED="1540555587043" ID="ID_168267294" MODIFIED="1540817580216" TEXT="Allow the sync only when the client is online" VSHIFT="12">
<node COLOR="#66cc00" CREATED="1540556127239" ID="ID_97484675" MODIFIED="1540817585045" TEXT="Online">
<node COLOR="#66cc00" CREATED="1540555605392" HGAP="16" ID="ID_1636341150" MODIFIED="1540817594005" TEXT=" Return the response" VSHIFT="-22">
<node COLOR="#66cc00" CREATED="1540555620274" HGAP="15" ID="ID_1214847173" MODIFIED="1540817646007" TEXT="Capture audit and transaction logs" VSHIFT="-16"/>
</node>
</node>
<node COLOR="#ff0000" CREATED="1540556130630" ID="ID_57379003" MODIFIED="1540817618392" TEXT="Offline">
<node COLOR="#ff0000" CREATED="1540556174783" HGAP="19" ID="ID_1946796848" MODIFIED="1540817625819" TEXT="Error message to be displayed" VSHIFT="20">
<node COLOR="#ff0000" CREATED="1540556357120" ID="ID_178115251" MODIFIED="1540817638033" TEXT="Capture transaction and audit logs" VSHIFT="15"/>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
