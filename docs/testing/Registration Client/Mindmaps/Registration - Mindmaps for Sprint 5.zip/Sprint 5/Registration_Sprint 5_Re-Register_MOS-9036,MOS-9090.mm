<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1543562421526" ID="ID_1390503806" MODIFIED="1543562695558" TEXT="Registration - Re-Register">
<node CREATED="1543563023166" ID="ID_1116870888" LINK="https://mosipid.atlassian.net/browse/MOS-9036" MODIFIED="1543564072414" POSITION="right" TEXT="MOS-9036">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1543563140794" ID="ID_950744071" MODIFIED="1543564097015" TEXT="Verify whether supervisor is allowed to view Re-Register page">
<node COLOR="#33cc00" CREATED="1543563194557" ID="ID_829580178" MODIFIED="1543564097015" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1543563244508" ID="ID_1995063666" MODIFIED="1543564097015" TEXT="The page will display list of RIDs which are marked as Re-Register by processor"/>
</node>
<node COLOR="#ff9900" CREATED="1543563237020" ID="ID_1659142165" MODIFIED="1543564109470" TEXT="No">
<node COLOR="#ff3300" CREATED="1543563268596" ID="ID_617027308" MODIFIED="1543564119006" TEXT="Check whether the user has supervisor access"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1543563282971" HGAP="13" ID="ID_1007682204" MODIFIED="1543564097014" TEXT="Verify whether preview of Registraion are displayed when user clicks RIDs" VSHIFT="19">
<node COLOR="#33cc00" CREATED="1543563194557" ID="ID_1058097280" MODIFIED="1543564097013" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1543563244508" ID="ID_1247094286" MODIFIED="1543564097013" TEXT="The page will display the acknowledgement slip of the registration"/>
</node>
<node COLOR="#ff9900" CREATED="1543563237020" ID="ID_1904769310" MODIFIED="1543564109470" TEXT="No">
<node COLOR="#ff3300" CREATED="1543563268596" ID="ID_1501456982" MODIFIED="1543564119006" TEXT="Display appropriate error message "/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1543563452825" HGAP="17" ID="ID_876491911" MODIFIED="1543564097014" TEXT="Verify user is able to mark the following status " VSHIFT="25">
<node COLOR="#33cc00" CREATED="1543563483031" ID="ID_1438988828" MODIFIED="1543564097013" TEXT="Informed">
<node COLOR="#33cc00" CREATED="1543563517304" ID="ID_495921036" MODIFIED="1543564097013" TEXT="If supervisor informs the individual by phone, email, physical mail or physical visit to re-register."/>
</node>
<node COLOR="#ff9900" CREATED="1543563486878" ID="ID_20610267" MODIFIED="1543564109470" TEXT="Cant Inform" VSHIFT="16">
<node COLOR="#ff3300" CREATED="1543563517304" ID="ID_191317527" MODIFIED="1543564119006" TEXT="If supervisor not able to inform the individual by phone, email, physical mail or physical visit to re-register."/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1543563555222" HGAP="15" ID="ID_475040234" MODIFIED="1543564097014" TEXT="Verify the status of the packet upon successful supervisor authentication" VSHIFT="39">
<node COLOR="#33cc00" CREATED="1543563598110" ID="ID_394879089" MODIFIED="1543564097014" TEXT="Authenticated">
<node COLOR="#33cc00" CREATED="1543563672885" ID="ID_1394166754" MODIFIED="1543564097014" TEXT="The actioned packets are removed from the &#x2018;-Re-register&#x2019; list"/>
</node>
<node COLOR="#ff9900" CREATED="1543563607790" ID="ID_1505657587" MODIFIED="1543564109470" TEXT="Unauthenticated">
<node COLOR="#ff3300" CREATED="1543563684212" ID="ID_1879049517" MODIFIED="1543564119005" TEXT="Display &apos;Authentication failure. Please try again&quot; error message and allow the user to re-try"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1543563694108" HGAP="-19" ID="ID_711862456" MODIFIED="1551090648973" TEXT="Verify whether RC allows to enter the type of biometric as configured" VSHIFT="59">
<node COLOR="#33cc00" CREATED="1543563732731" ID="ID_937609020" MODIFIED="1543564097014" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1543563741027" ID="ID_15748177" MODIFIED="1543564097014" TEXT="Display the fingerprint, iris or face biometics option"/>
</node>
<node COLOR="#ff9900" CREATED="1543563737259" ID="ID_1652374808" MODIFIED="1543564109469" TEXT="No">
<node COLOR="#ff3300" CREATED="1543563816417" ID="ID_1535679117" MODIFIED="1543564119005" TEXT="Display appropriate alert message"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="-32" ID="ID_1282327894" MODIFIED="1551090619497" TEXT="Verification of Txn details for Audit purpose" VSHIFT="23">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_548853522" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1086814999" MODIFIED="1542008615188" TEXT="Store all the details under &quot;Audit_Log&quot; table such as user id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1200248677" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_1008217879" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
<node CREATED="1543563023166" ID="ID_1815241586" LINK="https://mosipid.atlassian.net/browse/MOS-9036" MODIFIED="1543571440561" POSITION="left" TEXT="MOS-9090">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1543563140794" ID="ID_707703677" MODIFIED="1551090694925" TEXT="Verify whether supervisor is allowed to view EOD process page">
<node COLOR="#33cc00" CREATED="1543563194557" ID="ID_173829750" MODIFIED="1543564097015" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1543563244508" ID="ID_45384112" MODIFIED="1551090708156" TEXT="The page will display list of RIDs which are marked as pending approval"/>
</node>
<node COLOR="#ff9900" CREATED="1543563237020" ID="ID_281141544" MODIFIED="1543564109470" TEXT="No">
<node COLOR="#ff3300" CREATED="1543563268596" ID="ID_1721346426" MODIFIED="1543564119006" TEXT="Check whether the user has supervisor access"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1543563282971" HGAP="13" ID="ID_68910382" MODIFIED="1543564097014" TEXT="Verify whether preview of Registraion are displayed when user clicks RIDs" VSHIFT="19">
<node COLOR="#33cc00" CREATED="1543563194557" ID="ID_1478423844" MODIFIED="1543564097013" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1543563244508" ID="ID_1435719297" MODIFIED="1543564097013" TEXT="The page will display the acknowledgement slip of the registration"/>
</node>
<node COLOR="#ff9900" CREATED="1543563237020" ID="ID_244205124" MODIFIED="1543564109470" TEXT="No">
<node COLOR="#ff3300" CREATED="1543563268596" ID="ID_1258938043" MODIFIED="1543564119006" TEXT="Display appropriate error message "/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1543563452825" HGAP="17" ID="ID_459981937" MODIFIED="1543564097014" TEXT="Verify user is able to mark the following status " VSHIFT="25">
<node COLOR="#33cc00" CREATED="1543563483031" ID="ID_1716973118" MODIFIED="1551090730088" TEXT="Approved">
<node COLOR="#33cc00" CREATED="1543563517304" ID="ID_1045077456" MODIFIED="1551090879104" TEXT="The packet status will be marked as approved"/>
</node>
<node COLOR="#ff9900" CREATED="1543563486878" ID="ID_1917621252" MODIFIED="1551090736793" TEXT="Rejected" VSHIFT="16">
<node COLOR="#ff3300" CREATED="1543563517304" ID="ID_1393434091" MODIFIED="1551090890531" TEXT="The packet status will be marked as Rejected"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1543563555222" HGAP="15" ID="ID_1663536381" MODIFIED="1543564097014" TEXT="Verify the status of the packet upon successful supervisor authentication" VSHIFT="39">
<node COLOR="#33cc00" CREATED="1543563598110" ID="ID_193018914" MODIFIED="1543564097014" TEXT="Authenticated">
<node COLOR="#33cc00" CREATED="1543563672885" ID="ID_310463663" MODIFIED="1551090904390" TEXT="The packet must not display again in EOD process screen"/>
</node>
<node COLOR="#ff9900" CREATED="1543563607790" ID="ID_1710487980" MODIFIED="1551090924034" TEXT="Authentication failed">
<node COLOR="#ff3300" CREATED="1543563684212" ID="ID_1759758490" MODIFIED="1543564119005" TEXT="Display &apos;Authentication failure. Please try again&quot; error message and allow the user to re-try"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1543563694108" HGAP="-19" ID="ID_1319811783" MODIFIED="1551090976149" TEXT="Verify whether RC allows to enter the biometric as configured" VSHIFT="59">
<node COLOR="#33cc00" CREATED="1543563732731" ID="ID_1770363460" MODIFIED="1543564097014" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1543563741027" ID="ID_1077200271" MODIFIED="1543564097014" TEXT="Display the fingerprint, iris or face biometics option"/>
</node>
<node COLOR="#ff9900" CREATED="1543563737259" ID="ID_1468683675" MODIFIED="1543564109469" TEXT="No">
<node COLOR="#ff3300" CREATED="1543563816417" ID="ID_504403546" MODIFIED="1543564119005" TEXT="Display appropriate alert message"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1543571515419" HGAP="-16" ID="ID_1223070782" MODIFIED="1551091008088" TEXT="Verify whether user is able to save the status as Reject without reasons" VSHIFT="49">
<node COLOR="#33cc00" CREATED="1543563732731" ID="ID_1313842458" MODIFIED="1543571562111" TEXT="No">
<node COLOR="#33cc00" CREATED="1543563741027" ID="ID_1783874637" MODIFIED="1543571586528" TEXT="Select the option and then save the packet"/>
</node>
<node COLOR="#ff9900" CREATED="1543563737259" ID="ID_1297828915" MODIFIED="1543571567160" TEXT="Yes">
<node COLOR="#ff3300" CREATED="1543563816417" ID="ID_1995011531" MODIFIED="1543564119005" TEXT="Display appropriate alert message"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1543571602762" HGAP="18" ID="ID_742530277" MODIFIED="1543571922829" TEXT="Verify the packet status are saved without supervisor authentication" VSHIFT="43">
<node COLOR="#33cc00" CREATED="1543563732731" ID="ID_404791242" MODIFIED="1543571562111" TEXT="No">
<node COLOR="#33cc00" CREATED="1543563741027" ID="ID_1948967075" MODIFIED="1543571653775" TEXT="Pass the user&apos;s authentication and then save it"/>
</node>
<node COLOR="#ff9900" CREATED="1543563737259" ID="ID_250045431" MODIFIED="1543571567160" TEXT="Yes">
<node COLOR="#ff3300" CREATED="1543563816417" ID="ID_1025678415" MODIFIED="1543564119005" TEXT="Display appropriate alert message"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1543571672330" HGAP="19" ID="ID_1475619817" MODIFIED="1543571922828" TEXT="Packets moved to after changing the status as" VSHIFT="36">
<node COLOR="#00cc00" CREATED="1543571700694" ID="ID_129581668" MODIFIED="1543571922828" TEXT="Approves or Rejected">
<node COLOR="#00cc00" CREATED="1543571746315" ID="ID_1287711881" MODIFIED="1543571922820" TEXT="Removed from the &#x2018;Pending Approval&#x2019; list and placed in upload location on the client and should be sent to server during the next upload."/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1543571844754" HGAP="17" ID="ID_1426294607" MODIFIED="1551091098957" TEXT="Packet status remains on pending approval for X days" VSHIFT="30">
<node COLOR="#00cc00" CREATED="1543571894805" ID="ID_191376021" MODIFIED="1543571922826" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1543571898117" ID="ID_452460294" MODIFIED="1543571922826" TEXT="It is auto-approved by the system. No Supervisor authentication is required for this."/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1543571951751" HGAP="18" ID="ID_947868333" MODIFIED="1543572083609" TEXT="Verify whether supervisor is able to view report of approved registrations" VSHIFT="37">
<node COLOR="#00cc00" CREATED="1543571979213" ID="ID_1638039757" MODIFIED="1543572083609" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1543572071520" ID="ID_78113269" MODIFIED="1543572083608" TEXT="The user to view a report of approved registrations for the past 15 days."/>
</node>
<node COLOR="#ff9900" CREATED="1543572093159" ID="ID_1009905854" MODIFIED="1543572122088" TEXT="No">
<node COLOR="#ff3300" CREATED="1543572100694" ID="ID_199545421" MODIFIED="1543572129176" TEXT="Check the role of the user and raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="-32" ID="ID_1192925495" MODIFIED="1551090619497" TEXT="Verification of Txn details for Audit purpose" VSHIFT="23">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_1183713434" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1446993402" MODIFIED="1542008615188" TEXT="Store all the details under &quot;Audit_Log&quot; table such as user id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_710894503" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_1966597218" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</map>
