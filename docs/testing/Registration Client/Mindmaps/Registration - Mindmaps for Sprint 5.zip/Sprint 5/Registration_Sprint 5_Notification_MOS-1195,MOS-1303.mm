<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1542005921098" ID="ID_1823567430" MODIFIED="1542005933427" TEXT="Registration - Notification">
<node COLOR="#00cc00" CREATED="1542005953834" ID="ID_900462418" LINK="https://mosipid.atlassian.net/browse/MOS-1195" MODIFIED="1542006930880" POSITION="right" TEXT="Acknowledgement receipt by SMS.">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1542006030477" ID="ID_804364147" MODIFIED="1542006961615" TEXT="Login as Registration Officer or Supervisor">
<node COLOR="#00cc00" CREATED="1542006108618" ID="ID_247839327" MODIFIED="1542006961615" TEXT="Verify whether Regsitration is completed and RID is generated" VSHIFT="-58">
<node COLOR="#00cc00" CREATED="1542006145664" ID="ID_261234530" MODIFIED="1542006961615" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542006212543" ID="ID_648339511" MODIFIED="1551089943172" TEXT="Send a SMS as &#x201c;Dear [Individual full name], Thank you for registering with Digital Identity platform. Your registration id is [Registration ID]. If there are any corrections to be made in your details, please contact the Registration centre within the next 4 days.&#x201d; (The template varies based on countries)">
<linktarget COLOR="#b0b0b0" DESTINATION="ID_648339511" ENDARROW="Default" ENDINCLINATION="774;0;" ID="Arrow_ID_794921752" SOURCE="ID_1103307876" STARTARROW="None" STARTINCLINATION="774;0;"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542006206569" ID="ID_122223654" MODIFIED="1542006961615" TEXT="No">
<node COLOR="#00cc00" CREATED="1542006396614" ID="ID_876629565" MODIFIED="1542006961615" TEXT="Continue with Registration process"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542006434094" ID="ID_1834713541" MODIFIED="1542006961615" TEXT="Verify whether the SMS gets triggered  to the mobile number provided during registration">
<node COLOR="#00cc00" CREATED="1542006541649" ID="ID_1737508631" MODIFIED="1542006961615" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542006549977" ID="ID_1074684143" MODIFIED="1542006961615" TEXT="Verify the content follows the standard format as mentioned above"/>
</node>
<node COLOR="#ff9900" CREATED="1542006613272" ID="ID_1828638609" MODIFIED="1542006972315" TEXT="No">
<node COLOR="#ff0000" CREATED="1542006618851" ID="ID_1948370408" MODIFIED="1542006982528" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542006639397" ID="ID_648510521" MODIFIED="1542006961615" TEXT="Verify the SMS should contain the registration number">
<node COLOR="#00cc00" CREATED="1542006541649" ID="ID_369404941" MODIFIED="1542006961615" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542006549977" ID="ID_5182448" MODIFIED="1542006961615" TEXT="Verify the content follows the standard format as mentioned above"/>
</node>
<node COLOR="#ff9900" CREATED="1542006613272" ID="ID_1412813184" MODIFIED="1542006972315" TEXT="No">
<node COLOR="#ff0000" CREATED="1542006618851" ID="ID_1336569017" MODIFIED="1542006982528" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542006677789" ID="ID_311248867" MODIFIED="1542006961615" TEXT="Verify the system trigger the SMS regardless of the applicant being an adult or child">
<node COLOR="#00cc00" CREATED="1542006541649" ID="ID_164687985" MODIFIED="1542006961615" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542006549977" ID="ID_395456799" MODIFIED="1542006961615" TEXT="Verify the content follows the standard format as mentioned above"/>
</node>
<node COLOR="#ff9900" CREATED="1542006613272" ID="ID_467830558" MODIFIED="1542006972315" TEXT="No">
<node COLOR="#ff0000" CREATED="1542006618851" ID="ID_1845811363" MODIFIED="1542006982528" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542006753522" ID="ID_1482935484" MODIFIED="1542006961615" TEXT="Verify the system send SMS only when it is online">
<node COLOR="#00cc00" CREATED="1542006541649" ID="ID_1685112092" MODIFIED="1542006961615" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542006549977" ID="ID_437522446" MODIFIED="1542006961615" TEXT="Verify the content follows the standard format as mentioned above"/>
</node>
</node>
<node COLOR="#33ff00" CREATED="1551089906733" HGAP="25" ID="ID_1160368486" MODIFIED="1551090020842" TEXT="Is machine online when registration is completed" VSHIFT="39">
<node COLOR="#33ff00" CREATED="1551089929498" ID="ID_1103307876" MODIFIED="1551090020840" TEXT="Yes">
<arrowlink DESTINATION="ID_648339511" ENDARROW="Default" ENDINCLINATION="774;0;" ID="Arrow_ID_794921752" STARTARROW="None" STARTINCLINATION="774;0;"/>
</node>
<node COLOR="#33ff00" CREATED="1551089931365" ID="ID_1843756887" MODIFIED="1551090020840" TEXT="No">
<node COLOR="#33ff00" CREATED="1551089949703" ID="ID_867838740" MODIFIED="1551090020838" TEXT="The SMS must be queued and sent when next online. "/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="21" ID="ID_1282327894" MODIFIED="1542006856929" TEXT="Verification of Txn details for Audit purpose" VSHIFT="43">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_548853522" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1086814999" MODIFIED="1542006907360" TEXT="Store all the details under &quot;Audit_Log&quot; table such as User id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields"/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1200248677" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_1008217879" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542005953834" ID="ID_460008110" LINK="https://mosipid.atlassian.net/browse/MOS-1303" MODIFIED="1542007137656" POSITION="left" TEXT="Acknowledgement receipt by Email.">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1542006030477" ID="ID_1233631132" MODIFIED="1542006961615" TEXT="Login as Registration Officer or Supervisor">
<node COLOR="#00cc00" CREATED="1542006108618" ID="ID_133886972" MODIFIED="1551090144668" TEXT="Verify whether Registration is completed and RID is generated" VSHIFT="-58">
<node COLOR="#00cc00" CREATED="1542006145664" ID="ID_241747567" MODIFIED="1542006961615" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542006212543" ID="ID_890632750" MODIFIED="1551090109067" TEXT="Send an Email as configured by admin">
<linktarget COLOR="#b0b0b0" DESTINATION="ID_890632750" ENDARROW="Default" ENDINCLINATION="503;0;" ID="Arrow_ID_1479750772" SOURCE="ID_967817800" STARTARROW="None" STARTINCLINATION="503;0;"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542006206569" ID="ID_1461947710" MODIFIED="1542006961615" TEXT="No">
<node COLOR="#00cc00" CREATED="1542006396614" ID="ID_361232074" MODIFIED="1542006961615" TEXT="Continue with Registration process"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542006434094" ID="ID_1042754916" MODIFIED="1542007221453" TEXT="Verify whether the Email gets triggered  to the mail id provided during registration">
<node COLOR="#00cc00" CREATED="1542006541649" ID="ID_103796811" MODIFIED="1542006961615" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542006549977" ID="ID_1336450614" MODIFIED="1542006961615" TEXT="Verify the content follows the standard format as mentioned above"/>
</node>
<node COLOR="#ff9900" CREATED="1542006613272" ID="ID_138121663" MODIFIED="1542006972315" TEXT="No">
<node COLOR="#ff0000" CREATED="1542006618851" ID="ID_1268066346" MODIFIED="1542006982528" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542006639397" ID="ID_1818230028" MODIFIED="1542007335199" TEXT="Verify the Email should contain the registration number">
<node COLOR="#00cc00" CREATED="1542006541649" ID="ID_379094399" MODIFIED="1542006961615" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542006549977" ID="ID_703139178" MODIFIED="1542006961615" TEXT="Verify the content follows the standard format as mentioned above"/>
</node>
<node COLOR="#ff9900" CREATED="1542006613272" ID="ID_1673804906" MODIFIED="1542006972315" TEXT="No">
<node COLOR="#ff0000" CREATED="1542006618851" ID="ID_977289568" MODIFIED="1542006982528" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542006677789" ID="ID_714112442" MODIFIED="1542006961615" TEXT="Verify the system trigger the SMS regardless of the applicant being an adult or child">
<node COLOR="#00cc00" CREATED="1542006541649" ID="ID_1340194145" MODIFIED="1542006961615" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542006549977" ID="ID_1310887190" MODIFIED="1542006961615" TEXT="Verify the content follows the standard format as mentioned above"/>
</node>
<node COLOR="#ff9900" CREATED="1542006613272" ID="ID_233744833" MODIFIED="1542006972315" TEXT="No">
<node COLOR="#ff0000" CREATED="1542006618851" ID="ID_1496896543" MODIFIED="1542006982528" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542006753522" ID="ID_726122631" MODIFIED="1542007373948" TEXT="Verify the system send Email only when it is online">
<node COLOR="#00cc00" CREATED="1542006541649" ID="ID_1948995594" MODIFIED="1542006961615" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542006549977" ID="ID_968680217" MODIFIED="1542006961615" TEXT="Verify the content follows the standard format as mentioned above"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542007380792" ID="ID_1967044616" MODIFIED="1542007490166" TEXT="Verify if mode of confirmation is set to Email and Registration is complete">
<node COLOR="#00cc00" CREATED="1542007436642" ID="ID_414180711" MODIFIED="1542007490166" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542006212543" ID="ID_670346402" MODIFIED="1542007287295" TEXT="Send an Email as configured by admin"/>
</node>
<node COLOR="#ff9900" CREATED="1542007443916" ID="ID_240282428" MODIFIED="1542007496931" TEXT="No">
<node COLOR="#ff0000" CREATED="1542006212543" ID="ID_1768922069" MODIFIED="1542007502687" TEXT="Do not send an Email "/>
</node>
</node>
<node COLOR="#ff9900" CREATED="1542007519962" ID="ID_756786776" MODIFIED="1542007590102" TEXT="Verify whether email gets bounced while sending">
<node COLOR="#ff9900" CREATED="1542007436642" ID="ID_1596353796" MODIFIED="1542007580072" TEXT="Yes">
<node COLOR="#ff0000" CREATED="1542006212543" ID="ID_67230932" MODIFIED="1542007571900" TEXT="Do not resend an Email "/>
</node>
</node>
<node COLOR="#33ff00" CREATED="1551090059664" ID="ID_441510989" MODIFIED="1551090123425" TEXT="Is machine online when registration is completed" VSHIFT="32">
<node COLOR="#33ff00" CREATED="1551090083739" ID="ID_967817800" MODIFIED="1551090123425" TEXT="Yes">
<arrowlink DESTINATION="ID_890632750" ENDARROW="Default" ENDINCLINATION="503;0;" ID="Arrow_ID_1479750772" STARTARROW="None" STARTINCLINATION="503;0;"/>
</node>
<node COLOR="#33ff00" CREATED="1551090085484" ID="ID_1957283175" MODIFIED="1551090123424" TEXT="No">
<node COLOR="#33ff00" CREATED="1551089949703" ID="ID_1685487247" MODIFIED="1551090020838" TEXT="The SMS must be queued and sent when next online. "/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="21" ID="ID_557210463" MODIFIED="1542006856929" TEXT="Verification of Txn details for Audit purpose" VSHIFT="43">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_1960169789" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_302124036" MODIFIED="1542006907360" TEXT="Store all the details under &quot;Audit_Log&quot; table such as User id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields"/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_856225308" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_71868796" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</node>
</map>
