<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1543560069146" ID="ID_1229878385" MODIFIED="1543560101767" TEXT="Registration - Face Capture">
<node CREATED="1543560172701" ID="ID_283857948" LINK="https://mosipid.atlassian.net/browse/MOS-1287" MODIFIED="1543561984047" POSITION="right" TEXT="MOS-1287">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1543560363281" HGAP="9" ID="ID_1633763523" MODIFIED="1551089053923" TEXT="Device registered" VSHIFT="-33">
<node COLOR="#00cc00" CREATED="1543560413866" ID="ID_564732360" MODIFIED="1543562002593" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1543560524754" ID="ID_1645630050" MODIFIED="1543562002588" TEXT="Proceed with the first camera that the system finds as it scans the ports of the machine, if more than one device is found"/>
</node>
<node COLOR="#ff9900" CREATED="1543560420258" ID="ID_100753825" MODIFIED="1543562014001" TEXT="No">
<node COLOR="#ff3300" CREATED="1543560433706" ID="ID_268364683" MODIFIED="1543562025903" TEXT="Display &quot;Camera not found. Please connect an on-boarded camera and retry.&quot; error message"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1543560666601" HGAP="17" ID="ID_1326891086" MODIFIED="1543562002588" TEXT="Verify whether camera displays face photo preview before capturing." VSHIFT="26">
<node COLOR="#00cc00" CREATED="1543560849175" ID="ID_326003698" MODIFIED="1543562002587" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1543560524754" ID="ID_1466791610" MODIFIED="1543562002587" TEXT="Proceed with the first camera that the system finds as it scans the ports of the machine"/>
</node>
<node COLOR="#ff9900" CREATED="1543560854079" ID="ID_1965439595" MODIFIED="1543562014000" TEXT="No">
<node COLOR="#ff3300" CREATED="1543560877671" ID="ID_1060695954" MODIFIED="1551089047748" TEXT="Verify whether device is registered"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1543561108501" ID="ID_1085429498" MODIFIED="1543562002587" TEXT="Verify whether the screen displays the indiviual photo upon capturing" VSHIFT="38">
<node COLOR="#00cc00" CREATED="1543561170762" ID="ID_858123447" MODIFIED="1543562002586" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1543561307991" ID="ID_1925317042" MODIFIED="1543562002584" TEXT="The Registration Officer should proceed to verify quality score."/>
</node>
<node COLOR="#ff9900" CREATED="1543561177289" ID="ID_713041701" MODIFIED="1543562014000" TEXT="No">
<node COLOR="#ff3300" CREATED="1543561396644" ID="ID_774865892" MODIFIED="1543562025903" TEXT="Re-capture the photo if the quality / photo is not capture"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1543561415741" HGAP="17" ID="ID_848357398" MODIFIED="1543562002586" TEXT="Exception photo Capture" VSHIFT="24">
<node COLOR="#00cc00" CREATED="1543561882814" ID="ID_811136061" MODIFIED="1543562002585" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1543561907486" ID="ID_1219472063" MODIFIED="1543562002585" TEXT="Allow exception photo capture only if an exception has been marked"/>
</node>
<node COLOR="#ff9900" CREATED="1543560854079" ID="ID_603498394" MODIFIED="1543562014000" TEXT="No">
<node COLOR="#ff3300" CREATED="1543560877671" ID="ID_129651668" MODIFIED="1551089086757" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="21" ID="ID_1282327894" MODIFIED="1542027715444" TEXT="Verification of Txn details for Audit purpose" VSHIFT="30">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_548853522" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1086814999" MODIFIED="1542008615188" TEXT="Store all the details under &quot;Audit_Log&quot; table such as user id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1200248677" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_1008217879" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</map>
