<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1542019425060" ID="ID_508519685" MODIFIED="1542019447535" TEXT="Registration - Device Onboarding">
<node CREATED="1542019478993" ID="ID_559404725" LINK="https://mosipid.atlassian.net/browse/MOS-1226" MODIFIED="1542027736473" POSITION="right" TEXT="Device Onboarding by RO / Supervisor">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1542019524642" HGAP="33" ID="ID_3917159" MODIFIED="1542027802483" TEXT="Verify user is in Device Mapping page" VSHIFT="-61">
<node COLOR="#33cc00" CREATED="1542019643994" HGAP="140" ID="ID_1256400607" MODIFIED="1542027802482" TEXT="Yes" VSHIFT="-18">
<node COLOR="#33cc00" CREATED="1542019653225" ID="ID_1306968005" MODIFIED="1542027802482" TEXT="Display the available Devices and Mapped Devices list will be empty."/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542026512231" ID="ID_821783037" MODIFIED="1542027802476" TEXT="Verify system shows a list of registered devices when Device Type = &#x2018;Fingerprint&#x2019; or &#x2018;Iris&#x2019; or &#x2018;Camera&#x2019; or &#x2018;Printer&#x2019; or &#x2018;Scanner&#x2019; or &#x2018;GPS&#x2019; or &#x2018;Barcode reader&#x2019;">
<node COLOR="#33cc00" CREATED="1542026757009" ID="ID_299548912" MODIFIED="1542027802476" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1542026780581" ID="ID_725145867" MODIFIED="1542027843167" TEXT="Display a list of registered devices of the selected device type available for mapping in a multi select list box"/>
</node>
<node COLOR="#ff9900" CREATED="1542026794020" ID="ID_707647950" MODIFIED="1542027832545" TEXT="No">
<node COLOR="#ff0000" CREATED="1542026842049" ID="ID_433822347" MODIFIED="1542027857586" TEXT="Allow the user to onboard new devices using admin portal"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542026871773" HGAP="14" ID="ID_39138569" MODIFIED="1542027802476" TEXT="Verify user is able to select one or more device and moves them to a &#x2018;mapped&#x2019; list box and submits." VSHIFT="50">
<node COLOR="#33cc00" CREATED="1542026928771" ID="ID_847529377" MODIFIED="1542027802476" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1542026958086" ID="ID_1028356706" MODIFIED="1542027802475" TEXT="Move the selected list to &quot;Mapped Devices&quot; and display &quot;Manufacturer name, Model Name and Serial No.&quot;"/>
</node>
<node COLOR="#ff9900" CREATED="1542026935258" ID="ID_141801244" MODIFIED="1542027832544" TEXT="No">
<node COLOR="#ff9900" CREATED="1542027050639" HGAP="24" ID="ID_827480639" MODIFIED="1542027832544" TEXT="Validate that every mapped model&#x2019;s validity end date is not a past date" VSHIFT="28">
<node COLOR="#ff9900" CREATED="1542027067183" ID="ID_1630200372" MODIFIED="1542027832544" TEXT="Yes">
<node COLOR="#ff0000" CREATED="1542027151353" ID="ID_668120883" MODIFIED="1542027857586" TEXT="Raise a defect"/>
</node>
<node COLOR="#ff9900" CREATED="1542027092949" ID="ID_1450390090" MODIFIED="1542027832544" TEXT="No">
<node COLOR="#ff0000" CREATED="1542027121314" ID="ID_559400072" MODIFIED="1542027857582" TEXT="Display &quot;One or more of the selected device models is no longer supported for registration. These devices will not be on-boarded.&quot;"/>
</node>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542027174031" ID="ID_368016040" MODIFIED="1542027802475" TEXT="Verify user is able to unmap the mapped device">
<node COLOR="#33cc00" CREATED="1542027219580" ID="ID_647394828" MODIFIED="1542027802475" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1542027228604" ID="ID_910917228" MODIFIED="1542027802474" TEXT="Move the selected device to Available list"/>
</node>
<node COLOR="#ff9900" CREATED="1542027224004" ID="ID_836683719" MODIFIED="1542027832543" TEXT="No">
<node COLOR="#ff0000" CREATED="1542027245658" ID="ID_306964050" MODIFIED="1542027857582" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542027305840" HGAP="17" ID="ID_1303358287" MODIFIED="1542027802474" TEXT="Verify there are  no limitation to the numbers of devices mapped to the machine." VSHIFT="39">
<node COLOR="#33cc00" CREATED="1542027367519" ID="ID_900445378" MODIFIED="1542027802474" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1542027372519" ID="ID_974322108" MODIFIED="1542027802473" TEXT="Move the device to the mapped device list"/>
</node>
<node COLOR="#ff9900" CREATED="1542027224004" ID="ID_972289766" MODIFIED="1542027832543" TEXT="No">
<node COLOR="#ff0000" CREATED="1542027245658" ID="ID_616512897" MODIFIED="1542027857581" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542027401918" ID="ID_1015360373" MODIFIED="1542027802473" TEXT="Verify the user is able to map the device though they are not connected">
<node COLOR="#33cc00" CREATED="1542027367519" ID="ID_545160702" MODIFIED="1542027802473" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1542027372519" ID="ID_336278869" MODIFIED="1542027802472" TEXT="Move the device to the mapped device list"/>
</node>
<node COLOR="#ff9900" CREATED="1542027224004" ID="ID_444149166" MODIFIED="1542027832543" TEXT="No">
<node COLOR="#ff0000" CREATED="1542027245658" ID="ID_570821628" MODIFIED="1542027857581" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542027533551" ID="ID_143943960" MODIFIED="1542027802471" TEXT="Verify the machine allows device on-boarding even with out internet connectivity " VSHIFT="15">
<node COLOR="#33cc00" CREATED="1542027367519" ID="ID_1259082408" MODIFIED="1542027802472" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1542027372519" ID="ID_1352561812" MODIFIED="1542027802472" TEXT="Move the device to the mapped device list"/>
</node>
<node COLOR="#ff9900" CREATED="1542027224004" ID="ID_579252380" MODIFIED="1542027832542" TEXT="No">
<node COLOR="#ff0000" CREATED="1542027245658" ID="ID_1506800087" MODIFIED="1542027857581" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="21" ID="ID_1282327894" MODIFIED="1542027715444" TEXT="Verification of Txn details for Audit purpose" VSHIFT="30">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_548853522" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1086814999" MODIFIED="1542008615188" TEXT="Store all the details under &quot;Audit_Log&quot; table such as user id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1200248677" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_1008217879" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</map>
