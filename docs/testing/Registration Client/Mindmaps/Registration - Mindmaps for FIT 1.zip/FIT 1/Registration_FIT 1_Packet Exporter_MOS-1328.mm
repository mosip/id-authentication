<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1538652043529" ID="ID_1537275495" MODIFIED="1539174985920" TEXT="Registration - Packet Exporter">
<node COLOR="#33cc00" CREATED="1538652853212" ID="ID_1386135746" LINK="https://mosipid.atlassian.net/browse/MOS-556" MODIFIED="1540443657802" POSITION="right" TEXT="Viewing pending approval packets">
<node COLOR="#33cc00" CREATED="1538652868587" HGAP="-115" ID="ID_49978482" MODIFIED="1539330063075" TEXT="Logged in as supervisor" VSHIFT="-112">
<edge COLOR="#00cc00"/>
<node COLOR="#33cc00" CREATED="1538652908178" ID="ID_392689235" MODIFIED="1539330063075" TEXT="Click &quot;Approve Registration&quot; tab">
<edge COLOR="#00cc00"/>
<node COLOR="#33cc00" CREATED="1538653251634" HGAP="-30" ID="ID_1492333909" MODIFIED="1539330063067" TEXT="Packets Available" VSHIFT="-106">
<edge COLOR="#00cc00"/>
<node COLOR="#33cc00" CREATED="1539074973729" ID="ID_811333051" MODIFIED="1539330063067" TEXT="Yes">
<edge COLOR="#00cc00"/>
<node COLOR="#33cc00" CREATED="1539075021428" ID="ID_1990271124" MODIFIED="1539330063067" TEXT="Display the packets that are only pending approval">
<edge COLOR="#00cc00"/>
</node>
</node>
<node COLOR="#ff6600" CREATED="1539074981898" ID="ID_1028953373" MODIFIED="1539330077211" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538653323771" ID="ID_665974899" MODIFIED="1539330077211" TEXT="Display &quot;No packets available that are pending approval&quot;">
<edge COLOR="#ff0000"/>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539074920128" ID="ID_1617848487" MODIFIED="1539330063067" TEXT="Packet details are displayed with &quot;Registration ID, Registration Type, Resident Name, Operator ID, Operator Name&quot; ">
<edge COLOR="#00cc00"/>
<node COLOR="#ff6600" CREATED="1539075100890" ID="ID_245291688" MODIFIED="1539330077207" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539329247495" ID="ID_1349599077" MODIFIED="1539329371624" TEXT="Display &quot;Appropriate error message&#x201d; / raise a defect">
<edge COLOR="#ff0000"/>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538653455078" HGAP="21" ID="ID_1677624651" MODIFIED="1539330063075" TEXT="System Issue while viewing the packets" VSHIFT="25">
<edge COLOR="#00cc00"/>
<node COLOR="#ff6600" CREATED="1538653493593" ID="ID_413998394" MODIFIED="1539330077211" TEXT="Yes">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539329247495" ID="ID_389225266" MODIFIED="1539329371624" TEXT="Display &quot;Appropriate error message&#x201d; / raise a defect">
<edge COLOR="#ff0000"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539075387608" ID="ID_777015536" MODIFIED="1539330063067" TEXT="No">
<edge COLOR="#00cc00"/>
<node COLOR="#33cc00" CREATED="1539075396431" ID="ID_598174731" MODIFIED="1539330063067" TEXT="Display the packets that are pending approval with above mentioned details">
<edge COLOR="#00cc00"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#ff6600" CREATED="1538652914214" HGAP="30" ID="ID_1933601034" MODIFIED="1539330077211" TEXT="Logged in as other than supervisor" VSHIFT="-51">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538653044634" ID="ID_1659665533" MODIFIED="1539330077211" TEXT="Verify the tab &quot;Approve Registration&quot; is not enabled / not displayed">
<edge COLOR="#ff0000"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="-119" ID="ID_1167196337" MODIFIED="1539075351749" TEXT="Verification of Txn details for Audit purpose" VSHIFT="43">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_648252266" MODIFIED="1539060406447" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1079503882" MODIFIED="1539004902947" TEXT="Store all the details under &quot;Audit_Log&quot; table"/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1951538127" MODIFIED="1539330077211" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539329247495" ID="ID_413936387" MODIFIED="1539329371624" TEXT="Display &quot;Appropriate error message&#x201d; / raise a defect">
<edge COLOR="#ff0000"/>
</node>
</node>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542086328784" ID="ID_20919798" LINK="https://mosipid.atlassian.net/browse/MOS-1328" MODIFIED="1542086890686" POSITION="left" TEXT="Push packets to server">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1542086395971" ID="ID_1660457828" MODIFIED="1542086890686" TEXT="Login as RO / Supervisor">
<node COLOR="#00cc00" CREATED="1542086412919" ID="ID_1241388957" MODIFIED="1542086890686" TEXT="Navigate to Upload packet page ">
<node COLOR="#00cc00" CREATED="1542086491465" ID="ID_494548225" MODIFIED="1542086890686" TEXT="Verify it display the list of RIDs that are pending upload.">
<node COLOR="#00cc00" CREATED="1542086504109" HGAP="99" ID="ID_291793457" MODIFIED="1542086890686" TEXT="Yes" VSHIFT="-3">
<node COLOR="#00cc00" CREATED="1542086520323" HGAP="19" ID="ID_21893678" MODIFIED="1542086890686" TEXT="It should display both pending packets include those that have never been sent to the server earlier, and those that have been marked for resending." VSHIFT="-11"/>
</node>
<node COLOR="#ff6600" CREATED="1542086508286" HGAP="115" ID="ID_35254773" MODIFIED="1542086902370" TEXT="No" VSHIFT="25">
<node COLOR="#ff0000" CREATED="1542086555106" HGAP="43" ID="ID_673680327" MODIFIED="1542086910653" TEXT="Display either no pending packetsor appropriate error message" VSHIFT="3"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542086617590" HGAP="24" ID="ID_1234583942" MODIFIED="1542086890686" TEXT="Verify whether it displays the result of each packet upload as &#x2018;Success&#x2019; or &#x2018;Failure&#x2019; upon clicking upload." VSHIFT="36">
<node COLOR="#00cc00" CREATED="1542086799814" ID="ID_590245507" MODIFIED="1542086890686" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542086813158" ID="ID_422056328" MODIFIED="1542086890686" TEXT="Packets that are successfully sent or resent will not be sent again unless the server requests for them."/>
</node>
<node COLOR="#ff6600" CREATED="1542086819167" ID="ID_331561962" MODIFIED="1542086902370" TEXT="No">
<node COLOR="#ff0000" CREATED="1542086827433" ID="ID_482077267" MODIFIED="1542086910653" TEXT="Packets for which upload fails will continue to be in pending state."/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="21" ID="ID_1282327894" MODIFIED="1542027715444" TEXT="Verification of Txn details for Audit purpose" VSHIFT="30">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_548853522" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1086814999" MODIFIED="1542008615188" TEXT="Store all the details under &quot;Audit_Log&quot; table such as user id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1200248677" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_1008217879" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
