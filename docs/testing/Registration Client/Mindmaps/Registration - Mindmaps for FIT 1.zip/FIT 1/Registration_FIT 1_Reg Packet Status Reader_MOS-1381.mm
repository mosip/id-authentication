<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1542087571805" ID="ID_1051440671" MODIFIED="1542087594183" TEXT="Registration - Registration Packet Status Reader">
<node COLOR="#00cc00" CREATED="1542087649919" ID="ID_1726463231" LINK="https://mosipid.atlassian.net/browse/MOS-1381" MODIFIED="1542088601867" POSITION="right" TEXT="Read Packet Status">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1542087690919" HGAP="13" ID="ID_622373765" MODIFIED="1542088645744" TEXT="Verify whether the sync can be made through manual or Scheduled" VSHIFT="-29">
<node COLOR="#00cc00" CREATED="1542087724763" ID="ID_799025038" MODIFIED="1542088645744" TEXT="Scheduled">
<node COLOR="#00cc00" CREATED="1542087763524" ID="ID_1653768857" MODIFIED="1542088645744" TEXT="Automated sync should run based on the frequency set up by the admin user."/>
</node>
<node COLOR="#00cc00" CREATED="1542087752307" ID="ID_76678319" MODIFIED="1542088645744" TEXT="Manual">
<node COLOR="#00cc00" CREATED="1542087775531" ID="ID_833287029" MODIFIED="1542088645744" TEXT="There should be no limit to the number of times and timing of triggering the manual sync."/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542087802415" HGAP="13" ID="ID_943410412" MODIFIED="1542088645744" TEXT="Verify whether user receive response from server with packet statuses when a request is send" VSHIFT="15">
<node COLOR="#00cc00" CREATED="1542087856229" ID="ID_1778791539" MODIFIED="1542088645744" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542087874281" HGAP="17" ID="ID_794418581" MODIFIED="1542088645740" TEXT="Server sends status of those Registration packets that were created in this specific machine, and whose status has changed since the last sync." VSHIFT="-14"/>
</node>
<node COLOR="#ff6600" CREATED="1542087861044" ID="ID_1713013709" MODIFIED="1542088669439" TEXT="No">
<node COLOR="#ff6600" CREATED="1542087881936" HGAP="22" ID="ID_1562146742" MODIFIED="1542088669439" TEXT="Verify whether the registration client is online" VSHIFT="22">
<node COLOR="#ff6600" CREATED="1542087905358" ID="ID_347500266" MODIFIED="1542088669424" TEXT="Yes">
<node COLOR="#ff0000" CREATED="1542087948256" ID="ID_187039485" MODIFIED="1542088684516" TEXT="Display appropriate error message"/>
</node>
<node COLOR="#ff6600" CREATED="1542087920758" ID="ID_1335255933" MODIFIED="1542088669439" TEXT="No">
<node COLOR="#ff0000" CREATED="1542087924598" ID="ID_426452658" MODIFIED="1542088684516" TEXT="Display &quot;You must be connected to the internet to sync data.&quot; error message"/>
</node>
</node>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542087991166" HGAP="17" ID="ID_1118649973" MODIFIED="1542088645740" TEXT="Verify whether the status of each packets gets saved after server sends the response" VSHIFT="23">
<node COLOR="#00cc00" CREATED="1542088042218" ID="ID_547363298" MODIFIED="1542088645736" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1542088048640" ID="ID_457929962" MODIFIED="1542088645732" TEXT="Save the statuses &#x2018;Processing&#x2019;, &#x2018;Processed&#x2019; or &#x2018;Resend&#x2019; as received for each packet. Statuses of other packets are not updated."/>
</node>
<node COLOR="#ff6600" CREATED="1542087905358" ID="ID_1451485316" MODIFIED="1542088669439" TEXT="No">
<node COLOR="#ff0000" CREATED="1542087948256" ID="ID_911370768" MODIFIED="1542088684516" TEXT="Display appropriate error message"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542088107732" HGAP="21" ID="ID_1791182719" MODIFIED="1542088645732" TEXT="Verify appropriate message is displayed based on the response" VSHIFT="45">
<node COLOR="#00cc00" CREATED="1542088142399" ID="ID_784673587" MODIFIED="1542088645732" TEXT="Success">
<node COLOR="#00cc00" CREATED="1542088156719" ID="ID_466828025" MODIFIED="1542088645732" TEXT="Display &quot;Sync successful&quot; message"/>
</node>
<node COLOR="#ff6600" CREATED="1542088146559" ID="ID_1952448919" MODIFIED="1542088669439" TEXT="Failure">
<node COLOR="#ff0000" CREATED="1542088172812" ID="ID_183529919" MODIFIED="1542088684516" TEXT="Display &quot;Sync failure&quot; message"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542088222298" HGAP="17" ID="ID_775572650" MODIFIED="1542088645732" TEXT="Verify  Registration Client behavior when the packet status is" VSHIFT="22">
<node COLOR="#00cc00" CREATED="1542088276992" HGAP="16" ID="ID_192526581" MODIFIED="1542088645732" TEXT="Processed" VSHIFT="-13">
<node COLOR="#00cc00" CREATED="1542088313824" ID="ID_1792751119" MODIFIED="1542088645724" TEXT="The  Registration Client immediately deletes the packets from the local machine whose status is received as &#x2018;Processed&#x2019;"/>
</node>
<node COLOR="#ff6600" CREATED="1542088328315" HGAP="11" ID="ID_1872783601" MODIFIED="1542088669439" TEXT="Other than processed" VSHIFT="27">
<node COLOR="#ff0000" CREATED="1542088350680" ID="ID_505527791" MODIFIED="1542088684516" TEXT="Just update the status of the packet in the client as received from server"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542088376854" HGAP="22" ID="ID_1540313643" MODIFIED="1542088645724" TEXT="Verify the Registration client behavior " VSHIFT="37">
<node COLOR="#00cc00" CREATED="1542088451307" HGAP="7" ID="ID_1891052898" MODIFIED="1542088645724" TEXT="When sync is running" VSHIFT="-19">
<node COLOR="#00cc00" CREATED="1542088464136" ID="ID_1747202390" MODIFIED="1542088645724" TEXT="The client should not allow the end user to perform any other action"/>
</node>
<node COLOR="#ff6600" CREATED="1542088512965" HGAP="4" ID="ID_153818950" MODIFIED="1542088669439" TEXT="not online or not open during a scheduled sync" VSHIFT="35">
<node COLOR="#ff0000" CREATED="1542088557298" ID="ID_791662371" MODIFIED="1542088684516" TEXT="The sync should be queued up and executed later.When the client is next launched and is online, check if the previous scheduled sync was executed. If not executed earlier, immediately start the sync."/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="21" ID="ID_1282327894" MODIFIED="1542027715444" TEXT="Verification of Txn details for Audit purpose" VSHIFT="30">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_548853522" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1086814999" MODIFIED="1542008615188" TEXT="Store all the details under &quot;Audit_Log&quot; table such as user id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1200248677" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_1008217879" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</map>
