<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1539167571065" ID="ID_1090430563" MODIFIED="1539167588055" TEXT="Registration - Login">
<node COLOR="#33cc00" CREATED="1539167627244" ID="ID_1686918985" LINK="https://mosipid.atlassian.net/browse/MOS-554" MODIFIED="1540443422516" POSITION="right" TEXT="Offline Mode">
<edge COLOR="#00cc00"/>
<node COLOR="#33cc00" CREATED="1538634468756" HGAP="14" ID="ID_1646555896" MODIFIED="1539256000943" TEXT="Ro / Supervisor logged in with Username + Password access - can be configured in admin portal" VSHIFT="2">
<node COLOR="#33cc00" CREATED="1538635063785" ID="ID_9234962" MODIFIED="1539069165608" TEXT="Display password based login page">
<node COLOR="#33cc00" CREATED="1538635119762" ID="ID_1958851739" MODIFIED="1539251269665" TEXT=";">
<node COLOR="#33cc00" CREATED="1538635451810" ID="ID_1492500418" MODIFIED="1539069165608" TEXT="RO / Supervisor">
<node COLOR="#33cc00" CREATED="1538637797831" ID="ID_641299333" MODIFIED="1539069165608" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539068795800" ID="ID_922524262" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068747681" ID="ID_1631048844" MODIFIED="1539330581748" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068766872" ID="ID_1300011321" MODIFIED="1539069194277" TEXT="Display &quot;You are not authorized to perform registration.&quot;"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538635476968" ID="ID_1204858322" MODIFIED="1539069165608" TEXT="Invalid Password">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_796272076" MODIFIED="1539069566396" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_1103809006" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538637809459" ID="ID_1317938244" MODIFIED="1539330581748" TEXT="Yes">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068863296" ID="ID_1575569130" MODIFIED="1539069194277" TEXT="Display &quot;Incorrect password&quot;"/>
</node>
</node>
<node COLOR="#ff6600" CREATED="1538635500744" ID="ID_552162455" MODIFIED="1539330581748" TEXT="Without username or password">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637853163" ID="ID_173105804" MODIFIED="1539069194277" TEXT="Display &quot;[Field name] is required:&quot;"/>
</node>
<node COLOR="#33cc00" CREATED="1538635614813" ID="ID_1457347404" MODIFIED="1539069165608" TEXT="User not onboarded">
<node COLOR="#33cc00" CREATED="1538637880458" ID="ID_1105027034" MODIFIED="1539069165608" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_832259678" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068901191" ID="ID_888486961" MODIFIED="1539330581748" TEXT="Yes">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068911520" ID="ID_1276051396" MODIFIED="1539069194277" TEXT="Display &quot;You have not been onboarded to use this client&quot;"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538635640418" ID="ID_572081012" MODIFIED="1539069165608" TEXT="Valid username and password">
<node COLOR="#33cc00" CREATED="1538637915123" ID="ID_1320319665" MODIFIED="1539069165608" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539068953567" ID="ID_1567194672" MODIFIED="1539069165608" TEXT="&quot;Display Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068957510" ID="ID_823711828" MODIFIED="1539330581748" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068966693" ID="ID_200367114" MODIFIED="1539069194277" TEXT="Display appropriate error message as above"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539069046577" ID="ID_1421666088" MODIFIED="1539069165608" TEXT="User is blacklisted">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_923525997" MODIFIED="1539069574044" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_440027494" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538635546306" HGAP="18" ID="ID_610501887" MODIFIED="1539330581748" TEXT="Yes" VSHIFT="-14">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637930387" ID="ID_895472723" MODIFIED="1539069194277" TEXT="Display &apos;You are not authorized to perform registration&quot;"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="16" ID="ID_1167196337" MODIFIED="1539004933785" TEXT="Verification of Txn details for Audit purpose" VSHIFT="86">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_648252266" MODIFIED="1539060406447" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1079503882" MODIFIED="1539004902947" TEXT="Store all the details under &quot;Audit_Log&quot; table"/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1951538127" MODIFIED="1539330581748" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_285530157" MODIFIED="1539330406352" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539167635896" HGAP="63" ID="ID_1061864922" LINK="https://mosipid.atlassian.net/browse/MOS-554" MODIFIED="1540443415435" POSITION="right" TEXT="Online Mode" VSHIFT="-17">
<edge COLOR="#00cc00"/>
<node COLOR="#33cc00" CREATED="1538634468756" HGAP="-3" ID="ID_10857501" MODIFIED="1539255976001" TEXT="Ro / Supervisor logged in with Username + Password access - can be configured in admin portal" VSHIFT="-36">
<node COLOR="#33cc00" CREATED="1538635063785" ID="ID_1869120666" MODIFIED="1539069165608" TEXT="Display password based login page">
<node COLOR="#33cc00" CREATED="1538635119762" ID="ID_580615457" MODIFIED="1539069165608" TEXT="Validate Username and password">
<node COLOR="#33cc00" CREATED="1538635451810" ID="ID_904209029" MODIFIED="1539069165608" TEXT="RO / Supervisor">
<node COLOR="#33cc00" CREATED="1538637797831" ID="ID_1213107081" MODIFIED="1539069165608" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539068795800" ID="ID_455960793" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068747681" ID="ID_906043979" MODIFIED="1539330581748" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068766872" ID="ID_496634193" MODIFIED="1539069194277" TEXT="Display &quot;You are not authorized to perform registration.&quot;"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538635476968" ID="ID_1949623562" MODIFIED="1539069165608" TEXT="Invalid Password">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_79360180" MODIFIED="1539069566396" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_1871310815" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538637809459" ID="ID_887167738" MODIFIED="1539330581748" TEXT="Yes">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068863296" ID="ID_1917058105" MODIFIED="1539069194277" TEXT="Display &quot;Incorrect password&quot;"/>
</node>
</node>
<node COLOR="#ff6600" CREATED="1538635500744" ID="ID_1953033789" MODIFIED="1539330581748" TEXT="Without username or password">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637853163" ID="ID_236944255" MODIFIED="1539069194277" TEXT="Display &quot;[Field name] is required:&quot;"/>
</node>
<node COLOR="#33cc00" CREATED="1538635614813" ID="ID_357232579" MODIFIED="1539069165608" TEXT="User not onboarded">
<node COLOR="#33cc00" CREATED="1538637880458" ID="ID_444355496" MODIFIED="1539069165608" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_1411513793" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068901191" ID="ID_4686843" MODIFIED="1539330581748" TEXT="Yes">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068911520" ID="ID_3820027" MODIFIED="1539069194277" TEXT="Display &quot;You have not been onboarded to use this client&quot;"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538635640418" ID="ID_1957094164" MODIFIED="1539069165608" TEXT="Valid username and password">
<node COLOR="#33cc00" CREATED="1538637915123" ID="ID_1792492445" MODIFIED="1539069165608" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539068953567" ID="ID_788659878" MODIFIED="1539069165608" TEXT="&quot;Display Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068957510" ID="ID_714544443" MODIFIED="1539330581748" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068966693" ID="ID_1526659711" MODIFIED="1539069194277" TEXT="Display appropriate error message as above"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539069046577" ID="ID_1562519354" MODIFIED="1539069165608" TEXT="User is blacklisted">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_564005151" MODIFIED="1539069574044" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_591401227" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538635546306" HGAP="18" ID="ID_1846051019" MODIFIED="1539330581748" TEXT="Yes" VSHIFT="-14">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637930387" ID="ID_1033404796" MODIFIED="1539069194277" TEXT="Display &apos;You are not authorized to perform registration&quot;"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="16" ID="ID_1534887366" MODIFIED="1539004933785" TEXT="Verification of Txn details for Audit purpose" VSHIFT="86">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_1470554124" MODIFIED="1539060406447" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_134776586" MODIFIED="1539004902947" TEXT="Store all the details under &quot;Audit_Log&quot; table"/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_935480929" MODIFIED="1539330581748" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_1580255843" MODIFIED="1539330406352" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538634478361" HGAP="52" ID="ID_1068162797" MODIFIED="1539255987969" STYLE="fork" TEXT="Ro / Supervisor logged in with Username + OTP access - can be configured in admin portal" VSHIFT="24">
<node COLOR="#33cc00" CREATED="1538635076134" HGAP="19" ID="ID_555096832" MODIFIED="1539069496703" TEXT="Display OTP based login page" VSHIFT="25">
<node COLOR="#33cc00" CREATED="1538635306570" HGAP="6" ID="ID_1401615552" MODIFIED="1539069496703" TEXT="Validate the username and OTP" VSHIFT="40">
<node COLOR="#33cc00" CREATED="1538635451810" ID="ID_1683376890" MODIFIED="1539069496703" TEXT="RO / Supervisor">
<node COLOR="#33cc00" CREATED="1538637797831" ID="ID_16401422" MODIFIED="1539069165608" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539068795800" ID="ID_1743550959" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068747681" ID="ID_319538881" MODIFIED="1539330581748" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068766872" ID="ID_1864901886" MODIFIED="1539069194277" TEXT="Display &quot;You are not authorized to perform registration.&quot;"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538635476968" ID="ID_1359095302" MODIFIED="1539069496703" TEXT="Invalid / Expired OTP">
<node COLOR="#33cc00" CREATED="1538637797831" ID="ID_756792650" MODIFIED="1539069549160" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068795800" ID="ID_191495234" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538638240214" ID="ID_1209146034" MODIFIED="1539330581752" TEXT="Yes">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539069294477" ID="ID_1937283975" MODIFIED="1539069542876" TEXT="Display &quot;Incorrect or expired OTP&quot;"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538635500744" HGAP="39" ID="ID_988741343" MODIFIED="1539330619446" TEXT="Mobile number not found" VSHIFT="-6">
<node COLOR="#33cc00" CREATED="1538637797831" ID="ID_1897685320" MODIFIED="1539069554194" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068795800" ID="ID_1441779535" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538638261000" ID="ID_1296814751" MODIFIED="1539330581752" TEXT="Yes">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539069341661" ID="ID_22055663" MODIFIED="1539069542876" TEXT="Display &quot;Unable to send OTP as you do not have a mobile number associated.&quot;"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538635640418" ID="ID_1765942052" MODIFIED="1539069496703" TEXT="valid username and OTP">
<node COLOR="#33cc00" CREATED="1538637915123" ID="ID_406363933" MODIFIED="1539069165608" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539068953567" ID="ID_1164683256" MODIFIED="1539069165608" TEXT="&quot;Display Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068957510" ID="ID_176287537" MODIFIED="1539330581752" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068966693" ID="ID_1277085169" MODIFIED="1539069194277" TEXT="Display appropriate error message as above"/>
</node>
</node>
<node COLOR="#ff6600" CREATED="1538637233727" ID="ID_1978963610" MODIFIED="1539330581752" TEXT="Without username or OTP">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637853163" ID="ID_1544175770" MODIFIED="1539069542876" TEXT="Display &quot;[Field name] is required:&quot;"/>
</node>
<node COLOR="#33cc00" CREATED="1538635614813" ID="ID_1357747360" MODIFIED="1539069165608" TEXT="User not onboarded">
<node COLOR="#33cc00" CREATED="1538637880458" ID="ID_1756776738" MODIFIED="1539069165608" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_739993056" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068901191" ID="ID_1146257422" MODIFIED="1539330581752" TEXT="Yes">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068911520" ID="ID_429449396" MODIFIED="1539069194277" TEXT="Display &quot;You have not been onboarded to use this client&quot;"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539069046577" ID="ID_979529147" MODIFIED="1539069165608" TEXT="User is blacklisted">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_1568660308" MODIFIED="1539069574044" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_1449798720" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538635546306" HGAP="18" ID="ID_216443313" MODIFIED="1539330581752" TEXT="Yes" VSHIFT="-14">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637930387" ID="ID_1421164137" MODIFIED="1539069194277" TEXT="Display &apos;You are not authorized to perform registration&quot;"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="16" ID="ID_1096773135" MODIFIED="1539004933785" TEXT="Verification of Txn details for Audit purpose" VSHIFT="86">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_1750743374" MODIFIED="1539060406447" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1352657876" MODIFIED="1539004902947" TEXT="Store all the details under &quot;Audit_Log&quot; table"/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_959963896" MODIFIED="1539330581752" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_483248776" MODIFIED="1539330406352" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538646493110" ID="ID_165610911" LINK="https://mosipid.atlassian.net/browse/MOS-554" MODIFIED="1542004157742" POSITION="left" TEXT="Validation of basic registration details">
<edge COLOR="#00cc00"/>
<node COLOR="#33cc00" CREATED="1538646645429" HGAP="-189" ID="ID_358050985" MODIFIED="1539069864447" TEXT="All mandatory fields and conditional mandatory fields are captured" VSHIFT="-124">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1538646773947" ID="ID_1443823864" MODIFIED="1539069864447" TEXT="Click Submit">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1538646840761" ID="ID_1731215273" MODIFIED="1539069864447" TEXT="Navigates to &quot;Registration ID generation and receipt printing.&quot;">
<edge COLOR="#33cc00"/>
</node>
</node>
</node>
<node COLOR="#ff6600" CREATED="1538646666455" HGAP="-71" ID="ID_1309560031" MODIFIED="1539069872664" TEXT="All / few mandatory fields and conditional mandatory fields are not captured" VSHIFT="171">
<edge COLOR="#ff0000"/>
<node COLOR="#ff6600" CREATED="1538646783164" ID="ID_331792655" MODIFIED="1539069785334" TEXT="Click Submit">
<node COLOR="#ff0000" CREATED="1538647050432" ID="ID_169089873" MODIFIED="1539069791495" TEXT="Display &quot;Missing data in [Field name]. Please go back and ensure data is entered&#x201d;"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="-214" ID="ID_892271384" MODIFIED="1539069842943" TEXT="Verification of Txn details for Audit purpose" VSHIFT="85">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_1798082574" MODIFIED="1539060406447" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_953381579" MODIFIED="1539004902947" TEXT="Store all the details under &quot;Audit_Log&quot; table"/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_102210612" MODIFIED="1539060478963" TEXT="System fails to capture Txn details">
<node COLOR="#ff0000" CREATED="1539060455389" ID="ID_934288027" MODIFIED="1539060473076" TEXT="Display appropriate error message"/>
</node>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542003696111" HGAP="4" ID="ID_498677033" LINK="https://mosipid.atlassian.net/browse/MOS-1186" MODIFIED="1542089844486" POSITION="left" TEXT="Temporary lock for Invalid Login - MOS-1186" VSHIFT="88">
<edge COLOR="#00cc00"/>
<node COLOR="#33cc00" CREATED="1538634468756" HGAP="33" ID="ID_835595492" MODIFIED="1542005439648" STYLE="fork" TEXT="Ro / Supervisor logged in with Username + Password access - can be configured in admin portal" VSHIFT="131">
<node COLOR="#33cc00" CREATED="1538635063785" HGAP="2" ID="ID_907681410" MODIFIED="1542005263204" TEXT="Display password based login page" VSHIFT="-112">
<node COLOR="#33cc00" CREATED="1538635119762" ID="ID_1354168580" MODIFIED="1542005044922" TEXT=";">
<node COLOR="#33cc00" CREATED="1538635640418" HGAP="71" ID="ID_1838345890" MODIFIED="1542005251446" TEXT="Valid username and password" VSHIFT="35">
<node COLOR="#33cc00" CREATED="1538637915123" ID="ID_696930340" MODIFIED="1542005044922" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539068953567" ID="ID_1292178457" MODIFIED="1542005044922" TEXT="&quot;Display Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068957510" ID="ID_1224202991" MODIFIED="1542005044922" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068966693" ID="ID_33066514" MODIFIED="1542005044922" TEXT="Display appropriate error message"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539069046577" HGAP="70" ID="ID_616734290" MODIFIED="1542005257930" TEXT="Login with Invalid password" VSHIFT="18">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_850602261" MODIFIED="1542005044922" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_1568567653" MODIFIED="1542005044922" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538635546306" HGAP="18" ID="ID_1984963153" MODIFIED="1542005044922" TEXT="Yes" VSHIFT="-14">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637930387" ID="ID_1531817917" MODIFIED="1542005609857" TEXT="Display &apos;Incorrect Password&quot; and set the count of invalid login = 1. The count gets increased for every invalid attempt"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542004360480" HGAP="96" ID="ID_583298599" MODIFIED="1542005243851" TEXT="User tried to login with invalid password &gt;= 5 times" VSHIFT="18">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_669487648" MODIFIED="1542005044922" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_1272610541" MODIFIED="1542005044922" TEXT="Display &quot;Login page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538635546306" HGAP="18" ID="ID_1243197174" MODIFIED="1542005044922" TEXT="Yes" VSHIFT="-14">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637930387" ID="ID_698555284" MODIFIED="1542005044922" TEXT="Display &apos;&#x201c;Your account has been temporarily locked as you have made 5 unsuccessful login attempts. Please try logging in after 30 minutes.&#x201d; "/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542004570856" HGAP="108" ID="ID_1543600331" MODIFIED="1542005246043" TEXT="Try login again with locked account before 30 mins" VSHIFT="21">
<node COLOR="#ff6600" CREATED="1538635546306" HGAP="18" ID="ID_1704675422" MODIFIED="1542005044922" TEXT="Yes" VSHIFT="3">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637930387" ID="ID_72313197" MODIFIED="1542005044922" TEXT="Display &apos;&#x201c;Your account has been temporarily locked as you have made 5 unsuccessful login attempts. Please try logging in after 30 minutes.&#x201d; "/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542004714307" HGAP="110" ID="ID_805432931" MODIFIED="1542005247884" TEXT="Try login again with locked account after 30 mins" VSHIFT="5">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_420256155" MODIFIED="1542005044938" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_105167878" MODIFIED="1542005044938" TEXT="Display &quot;Login page&quot; and reset the count of invalid login attempts to 0."/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="112" ID="ID_318974386" MODIFIED="1542005236742" TEXT="Verification of Txn details for Audit purpose" VSHIFT="19">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_26594101" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1933929321" MODIFIED="1542005044938" TEXT="Store all the details under &quot;Audit_Log&quot; table"/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_453835978" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_739645953" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538634468756" HGAP="79" ID="ID_387013996" MODIFIED="1542005432725" STYLE="fork" TEXT="Ro / Supervisor logged in with Username + OTP access - can be configured in admin portal" VSHIFT="64">
<node COLOR="#33cc00" CREATED="1538635063785" HGAP="2" ID="ID_992510091" MODIFIED="1542005305383" TEXT="Display OTP based login page" VSHIFT="-112">
<node COLOR="#33cc00" CREATED="1538635119762" ID="ID_1406461104" MODIFIED="1542005044922" TEXT=";">
<node COLOR="#33cc00" CREATED="1538635640418" HGAP="71" ID="ID_218401053" MODIFIED="1542005312616" TEXT="Valid username and OTP" VSHIFT="35">
<node COLOR="#33cc00" CREATED="1538637915123" ID="ID_928741984" MODIFIED="1542005044922" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539068953567" ID="ID_1245005356" MODIFIED="1542005044922" TEXT="&quot;Display Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068957510" ID="ID_1869585665" MODIFIED="1542005044922" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068966693" ID="ID_1532603233" MODIFIED="1542005044922" TEXT="Display appropriate error message"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539069046577" HGAP="70" ID="ID_1430217988" MODIFIED="1542005320192" TEXT="Login with Invalid OTP" VSHIFT="18">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_313082667" MODIFIED="1542005044922" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_89863324" MODIFIED="1542005044922" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538635546306" HGAP="18" ID="ID_1883832082" MODIFIED="1542005044922" TEXT="Yes" VSHIFT="-14">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637930387" ID="ID_76231208" MODIFIED="1542005602912" TEXT="Display &apos;Incorrect OTP&quot; and set the count of invalid login = 1.The count gets increased for every invalid attempt"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542004360480" HGAP="96" ID="ID_1843642310" MODIFIED="1542005330164" TEXT="User tried to login with invalid OTP &gt;= 5 times" VSHIFT="18">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_939074686" MODIFIED="1542005044922" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_542153096" MODIFIED="1542005044922" TEXT="Display &quot;Login page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538635546306" HGAP="18" ID="ID_1350211356" MODIFIED="1542005044922" TEXT="Yes" VSHIFT="-14">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637930387" ID="ID_109723176" MODIFIED="1542005044922" TEXT="Display &apos;&#x201c;Your account has been temporarily locked as you have made 5 unsuccessful login attempts. Please try logging in after 30 minutes.&#x201d; "/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542004570856" HGAP="108" ID="ID_1836495176" MODIFIED="1542005246043" TEXT="Try login again with locked account before 30 mins" VSHIFT="21">
<node COLOR="#ff6600" CREATED="1538635546306" HGAP="18" ID="ID_737018669" MODIFIED="1542005044922" TEXT="Yes" VSHIFT="3">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637930387" ID="ID_1928428992" MODIFIED="1542005044922" TEXT="Display &apos;&#x201c;Your account has been temporarily locked as you have made 5 unsuccessful login attempts. Please try logging in after 30 minutes.&#x201d; "/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542004714307" HGAP="110" ID="ID_1800753157" MODIFIED="1542005247884" TEXT="Try login again with locked account after 30 mins" VSHIFT="5">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_618383467" MODIFIED="1542005044938" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_1805417728" MODIFIED="1542005044938" TEXT="Display &quot;Login page&quot; and reset the count of invalid login attempts to 0."/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="112" ID="ID_1282327894" MODIFIED="1542005236742" TEXT="Verification of Txn details for Audit purpose" VSHIFT="19">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_548853522" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1086814999" MODIFIED="1542005044938" TEXT="Store all the details under &quot;Audit_Log&quot; table"/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1200248677" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_1008217879" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538634468756" HGAP="198" ID="ID_1980749879" MODIFIED="1542005467467" STYLE="fork" TEXT="RO / Supervisor logged in with Username + Biometric access - can be configured in admin portal" VSHIFT="-84">
<node COLOR="#33cc00" CREATED="1538635063785" HGAP="2" ID="ID_1192525556" MODIFIED="1542005477267" TEXT="Display Biometric based login page" VSHIFT="-112">
<node COLOR="#33cc00" CREATED="1538635119762" ID="ID_239144638" MODIFIED="1542005044922" TEXT=";">
<node COLOR="#33cc00" CREATED="1538635640418" HGAP="71" ID="ID_833024103" MODIFIED="1542005489914" TEXT="Valid username and Biometric" VSHIFT="35">
<node COLOR="#33cc00" CREATED="1538637915123" ID="ID_1771454500" MODIFIED="1542005044922" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539068953567" ID="ID_399774979" MODIFIED="1542005044922" TEXT="&quot;Display Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068957510" ID="ID_1743370204" MODIFIED="1542005044922" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068966693" ID="ID_1734183705" MODIFIED="1542005044922" TEXT="Display appropriate error message"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539069046577" HGAP="70" ID="ID_1817960262" MODIFIED="1542005503084" TEXT="Login with Invalid Biometric" VSHIFT="18">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_621906743" MODIFIED="1542005044922" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_1174632843" MODIFIED="1542005044922" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538635546306" HGAP="18" ID="ID_1839204860" MODIFIED="1542005044922" TEXT="Yes" VSHIFT="-14">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637930387" ID="ID_906615106" MODIFIED="1542005593366" TEXT="Display appropriate alert message and set the count of invalid login = 1. The count gets increased for every invalid attempt"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542004360480" HGAP="96" ID="ID_1574149187" MODIFIED="1542005538461" TEXT="User tried to login with invalid Biometric  &gt;= 5 times" VSHIFT="18">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_167241346" MODIFIED="1542005044922" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_339243951" MODIFIED="1542005044922" TEXT="Display &quot;Login page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538635546306" HGAP="18" ID="ID_663204635" MODIFIED="1542005044922" TEXT="Yes" VSHIFT="-14">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637930387" ID="ID_474077573" MODIFIED="1542005044922" TEXT="Display &apos;&#x201c;Your account has been temporarily locked as you have made 5 unsuccessful login attempts. Please try logging in after 30 minutes.&#x201d; "/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542004570856" HGAP="108" ID="ID_571627172" MODIFIED="1542005246043" TEXT="Try login again with locked account before 30 mins" VSHIFT="21">
<node COLOR="#ff6600" CREATED="1538635546306" HGAP="18" ID="ID_668557979" MODIFIED="1542005044922" TEXT="Yes" VSHIFT="3">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637930387" ID="ID_1798015321" MODIFIED="1542005044922" TEXT="Display &apos;&#x201c;Your account has been temporarily locked as you have made 5 unsuccessful login attempts. Please try logging in after 30 minutes.&#x201d; "/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1542004714307" HGAP="110" ID="ID_1234043457" MODIFIED="1542005247884" TEXT="Try login again with locked account after 30 mins" VSHIFT="5">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_95080835" MODIFIED="1542005044938" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_1867739197" MODIFIED="1542005044938" TEXT="Display &quot;Login page&quot; and reset the count of invalid login attempts to 0."/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="112" ID="ID_569492131" MODIFIED="1542005236742" TEXT="Verification of Txn details for Audit purpose" VSHIFT="19">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_520354066" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_426336363" MODIFIED="1542005044938" TEXT="Store all the details under &quot;Audit_Log&quot; table"/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1481608399" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_371600325" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542089860493" ID="ID_1318669804" LINK="https://mosipid.atlassian.net/browse/MOS-8328" MODIFIED="1542090777116" POSITION="right" TEXT="Login with Fingerprint - MOS-8328">
<node COLOR="#33cc00" CREATED="1538634468756" HGAP="-153" ID="ID_339964646" MODIFIED="1542090656347" TEXT="Ro / Supervisor logged in with Username + Fingerprint access - can be configured in admin portal" VSHIFT="108">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1542089982247" ID="ID_15727897" MODIFIED="1542090698567" TEXT="Display Fingerprint based login page">
<node COLOR="#33cc00" CREATED="1542090003575" ID="ID_840639653" MODIFIED="1542090698567" TEXT="Validate the Fingerprint and username">
<node COLOR="#33cc00" CREATED="1542090025691" HGAP="12" ID="ID_1720735005" MODIFIED="1542090698567" TEXT="Valid username and fingerprint match found" VSHIFT="-47">
<node COLOR="#33cc00" CREATED="1542090047371" ID="ID_1258251705" MODIFIED="1542090698567" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1542090055636" ID="ID_829903910" MODIFIED="1542090711994" TEXT="Display the home page"/>
</node>
<node COLOR="#ff6600" CREATED="1542090050498" ID="ID_833998144" MODIFIED="1542090732039" TEXT="No">
<node COLOR="#ff0000" CREATED="1542090087236" ID="ID_904825612" MODIFIED="1542090757757" TEXT="Display appropriate error message"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542090099512" ID="ID_315691866" MODIFIED="1542090698567" TEXT="Missing mandatory fields while login">
<node COLOR="#ff6600" CREATED="1542090047371" ID="ID_1880825247" MODIFIED="1542090732039" TEXT="Yes">
<node COLOR="#ff0000" CREATED="1542090055636" ID="ID_1416739732" MODIFIED="1542090757742" TEXT="Display &quot;[Field name] is required&quot; error message"/>
</node>
<node COLOR="#33cc00" CREATED="1542090050498" ID="ID_1014631771" MODIFIED="1542090698567" TEXT="No">
<node COLOR="#33cc00" CREATED="1542090055636" ID="ID_189143031" MODIFIED="1542090698567" TEXT="Display the home page"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538635614813" ID="ID_802515070" MODIFIED="1539069165608" TEXT="User not onboarded">
<node COLOR="#33cc00" CREATED="1538637880458" ID="ID_1390925172" MODIFIED="1539069165608" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_1257778144" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068901191" ID="ID_1813882312" MODIFIED="1539330581752" TEXT="Yes">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068911520" ID="ID_947650966" MODIFIED="1539069194277" TEXT="Display &quot;You have not been onboarded to use this client&quot;"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539069046577" ID="ID_1774812425" MODIFIED="1539069165608" TEXT="User is blacklisted">
<node COLOR="#33cc00" CREATED="1539068843439" ID="ID_1863386032" MODIFIED="1539069574044" TEXT="No">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_495175619" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538635546306" HGAP="18" ID="ID_343002815" MODIFIED="1539330581752" TEXT="Yes" VSHIFT="-14">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1538637930387" ID="ID_431585114" MODIFIED="1539069194277" TEXT="Display &apos;You are not authorized to perform registration&quot;"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542090025691" HGAP="12" ID="ID_612143777" MODIFIED="1542090698567" TEXT="Login with valid username and invalid fingerprint match and vice-versa" VSHIFT="-47">
<node COLOR="#ff6600" CREATED="1542090047371" ID="ID_1260179301" MODIFIED="1542090732039" TEXT="Yes">
<node COLOR="#ff0000" CREATED="1542090055636" ID="ID_393538136" MODIFIED="1542090757742" TEXT="Display &quot;Fingerprint match not found&quot; error message / appropriate error message"/>
</node>
<node COLOR="#33cc00" CREATED="1542090050498" ID="ID_679518885" MODIFIED="1542090698567" TEXT="No">
<node COLOR="#33cc00" CREATED="1542090087236" ID="ID_500982258" MODIFIED="1542090698552" TEXT="Display home page"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542090271590" HGAP="22" ID="ID_260926631" MODIFIED="1542090765759" TEXT="Login with device that is not onboarded" VSHIFT="-40">
<node COLOR="#33cc00" CREATED="1538637880458" HGAP="17" ID="ID_1298512370" MODIFIED="1542090306023" TEXT="No" VSHIFT="-24">
<node COLOR="#33cc00" CREATED="1539068872840" ID="ID_634540943" MODIFIED="1539069165608" TEXT="Display &quot;Home page&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539068901191" ID="ID_1424760430" MODIFIED="1539330581752" TEXT="Yes">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539068911520" ID="ID_1947816483" MODIFIED="1542090320757" TEXT="Display &quot;Fingerprint device not found&quot;"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542090343887" ID="ID_1576935965" MODIFIED="1542090698552" TEXT="While login found more than one onboarded device">
<node COLOR="#33cc00" CREATED="1542090377651" ID="ID_969682487" MODIFIED="1542090698552" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1542090382459" ID="ID_1934635333" MODIFIED="1542090698552" TEXT="Proceed with the first fingerprint device that the system finds as it scans the ports of the machine"/>
</node>
</node>
<node COLOR="#ff6600" CREATED="1542090513759" HGAP="21" ID="ID_99683248" MODIFIED="1542090732039" TEXT="Number of attempts with invalid fingerprint" VSHIFT="61">
<node COLOR="#ff6600" CREATED="1542090551395" ID="ID_1337158871" MODIFIED="1542090732039" TEXT="&gt;=5">
<node COLOR="#ff0000" CREATED="1542090570536" ID="ID_1766962145" MODIFIED="1542090757742" TEXT="Temporarily lock the account for 30 mins and user will not be allowed to login for that period even if he tried with correct data"/>
</node>
<node COLOR="#ff6600" CREATED="1542090561439" ID="ID_1781149490" MODIFIED="1542090732039" TEXT="&lt;5">
<node COLOR="#ff0000" CREATED="1542090618195" ID="ID_393473468" MODIFIED="1542090757742" TEXT="Display appropriate error message and allow the user to enter login details"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
