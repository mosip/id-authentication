<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1546494903648" ID="ID_750264401" MODIFIED="1546511448560" TEXT="Reg - Pre-Registration Data Sync">
<node COLOR="#00cc00" CREATED="1546498546047" HGAP="-51" ID="ID_954533482" MODIFIED="1546506582807" POSITION="right" TEXT="Download pre-reg data" VSHIFT="-65">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1546494948945" ID="ID_1779071096" LINK="https://mosipid.atlassian.net/browse/MOS-1223" MODIFIED="1546506353002" TEXT="MOS-1200&amp;MOS-1223">
<node COLOR="#00cc00" CREATED="1546497274382" HGAP="6" ID="ID_453568577" MODIFIED="1551691234606" TEXT="Verify whether the &quot;Download Pre-Registration Data&quot; link is displayed" VSHIFT="-49">
<node COLOR="#00cc00" CREATED="1546497760308" ID="ID_1456311244" MODIFIED="1546500552425" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1546497812659" ID="ID_1635567585" MODIFIED="1546500552425" TEXT="Click the download link">
<node COLOR="#00cc00" CREATED="1546497851115" ID="ID_1704872233" MODIFIED="1546500552410" TEXT="The system should initiate manual download of pre-registration demographic data "/>
</node>
</node>
<node COLOR="#ff6600" CREATED="1546497765187" ID="ID_1363870534" MODIFIED="1546505989314" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1546497862098" ID="ID_1854411937" MODIFIED="1546500611372" TEXT="Raise a defect or alert the user"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1546497914079" HGAP="11" ID="ID_1162616110" MODIFIED="1546500552410" TEXT="Verify the downloaded pre-registration detail includes only Demogrpahic and not documents" VSHIFT="10">
<node COLOR="#00cc00" CREATED="1546498013188" ID="ID_229333319" MODIFIED="1546500552410" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1546498026748" ID="ID_1381316064" MODIFIED="1546500552410" TEXT="Verify the details are correct and the documents should be in view only mode"/>
</node>
<node COLOR="#ff6600" CREATED="1546498018091" ID="ID_717613133" MODIFIED="1546505989314" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1546497862098" ID="ID_1059053313" MODIFIED="1546500611372" TEXT="Raise a defect or alert the user"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1546498119903" ID="ID_1900135490" MODIFIED="1546500552410" TEXT="Verify The pre-registration data is downloadable" VSHIFT="27">
<node COLOR="#00cc00" CREATED="1546498147461" ID="ID_728886247" MODIFIED="1546500552410" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1546498157920" ID="ID_169729934" MODIFIED="1546500552410" TEXT="The pre-registration data should be downloaded only for that particular registration centre, where the pre-registration data download is initiated"/>
</node>
<node COLOR="#ff6600" CREATED="1546498018091" ID="ID_1693246739" MODIFIED="1546505989314" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1546497862098" ID="ID_1858622309" MODIFIED="1546500611372" TEXT="Raise a defect or alert the user"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1546498188488" HGAP="14" ID="ID_980672995" MODIFIED="1546500552410" TEXT="Verify the pre-registration data is downloadable only for config days" VSHIFT="50">
<node COLOR="#00cc00" CREATED="1546498221138" ID="ID_214669750" MODIFIED="1546500552410" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1546498231555" ID="ID_1681720881" MODIFIED="1546500552410" TEXT="The system should download the pre-registration data from current date+1 to current date+7"/>
</node>
<node COLOR="#ff6600" CREATED="1546498018091" ID="ID_811465011" MODIFIED="1546505989314" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1546497862098" ID="ID_948891797" MODIFIED="1546500611372" TEXT="Raise a defect or alert the user"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1546498263129" HGAP="3" ID="ID_1912677878" MODIFIED="1546500552410" TEXT="Verify while downloading the data, the status is shown in green progression bar" VSHIFT="38">
<node COLOR="#00cc00" CREATED="1546498221138" ID="ID_540443748" MODIFIED="1546500552410" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1546498231555" ID="ID_54253739" MODIFIED="1546500552410" TEXT="The system should display a green colored bar to indicate the progress of pre-registration data download"/>
</node>
<node COLOR="#ff6600" CREATED="1546498018091" ID="ID_543748814" MODIFIED="1546505989314" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1546497862098" ID="ID_197095457" MODIFIED="1546500611372" TEXT="Raise a defect or alert the user"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1546498343038" HGAP="5" ID="ID_625082988" MODIFIED="1546500552410" TEXT="Verify the behavior of previously downloaded data on next download" VSHIFT="46">
<node COLOR="#00cc00" CREATED="1546498430204" ID="ID_1209482238" MODIFIED="1546500552410" TEXT="With existing data">
<node COLOR="#00cc00" CREATED="1546498450925" ID="ID_131600667" MODIFIED="1546500552410" TEXT="The downloaded pre-registration data should overwrite the previously downloaded data for the same pre-registration id"/>
</node>
<node COLOR="#00cc00" CREATED="1546498437271" ID="ID_1850074729" MODIFIED="1546500577037" TEXT="Without existing data">
<node COLOR="#00cc00" CREATED="1546498457409" ID="ID_1466629209" MODIFIED="1546500577037" TEXT="Download the data and place it in the config path"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="9" ID="ID_1282327894" MODIFIED="1546498495098" TEXT="Verification of Txn details for Audit purpose" VSHIFT="34">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_548853522" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1086814999" MODIFIED="1546498515692" TEXT="Store all the details under &quot;Audit_Log&quot; table such as User id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1200248677" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_1008217879" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
<node CREATED="1546506498545" HGAP="-100" ID="ID_1287832448" MODIFIED="1546508396825" POSITION="right" TEXT="Encrypt and decrypt pre-registration packets " VSHIFT="-154">
<edge COLOR="#00cc00"/>
<node CREATED="1546506613264" ID="ID_1113791391" LINK="https://mosipid.atlassian.net/browse/MOS-1343" MODIFIED="1546508396825" TEXT="MOS-1343">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1546506723963" HGAP="13" ID="ID_67019487" MODIFIED="1546508429248" TEXT="Verify the RO is able to initiate a request for receiving pre registration id data." VSHIFT="-2">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1546508131968" ID="ID_573392328" MODIFIED="1546508429248" TEXT="Yes">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1546508144036" ID="ID_21139771" MODIFIED="1546508429248" TEXT="The packets will be received as zip files through secure mode">
<edge COLOR="#00cc00"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1546508136643" ID="ID_1119167697" MODIFIED="1546508429248" TEXT="No">
<node COLOR="#00cc00" CREATED="1539089688847" ID="ID_1066441156" MODIFIED="1546508429248" TEXT="Display appropriate alert message if no data is available for the PRID"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="9" ID="ID_1021783307" MODIFIED="1546498495098" TEXT="Verification of Txn details for Audit purpose" VSHIFT="34">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_163075645" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1629456931" MODIFIED="1546498515692" TEXT="Store all the details under &quot;Audit_Log&quot; table such as User id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1191661596" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_795182154" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1546508193515" HGAP="9" ID="ID_724158804" MODIFIED="1546508429248" TEXT="Behavior of RC when pre-registration data is received" VSHIFT="53">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1546508264219" ID="ID_234860628" MODIFIED="1546508429248" TEXT="system performs the encryption and decryption functionality by integrating/calling the Kernel Encryption/Decryption and Key Management component">
<edge COLOR="#00cc00"/>
</node>
</node>
</node>
</node>
<node COLOR="#00cc00" CREATED="1546500975314" ID="ID_944724480" MODIFIED="1546506568095" POSITION="left" TEXT="Download pre-reg data based on PRID">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1546501010041" ID="ID_1766958249" LINK="https://mosipid.atlassian.net/browse/MOS-1277" MODIFIED="1546506353002" TEXT="MOS-1277&amp;MOS-1367">
<node COLOR="#00cc00" CREATED="1546501060703" HGAP="14" ID="ID_1594670822" MODIFIED="1546505924991" TEXT="Verify whether the Reg client fetch Demo data by entering a pre registration id and clicks on &#x201c;fetch data&#x201d;" VSHIFT="-64">
<node COLOR="#00cc00" CREATED="1546501142993" ID="ID_1419069975" MODIFIED="1546505924976" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1546505258529" ID="ID_915978185" MODIFIED="1546505924976" TEXT="The system should fetch the demographic details of the resident and pre populate the form if there is exactly one match for pre registration id in the local system."/>
</node>
<node COLOR="#ff6600" CREATED="1546501148900" ID="ID_906365317" MODIFIED="1546505973164" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1546505769362" ID="ID_809367342" MODIFIED="1546505943797" TEXT="Display an alert message"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="9" ID="ID_1819375041" MODIFIED="1546498495098" TEXT="Verification of Txn details for Audit purpose" VSHIFT="34">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_1037390396" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_298585311" MODIFIED="1546498515692" TEXT="Store all the details under &quot;Audit_Log&quot; table such as User id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1656418462" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_249200154" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</node>
</map>
