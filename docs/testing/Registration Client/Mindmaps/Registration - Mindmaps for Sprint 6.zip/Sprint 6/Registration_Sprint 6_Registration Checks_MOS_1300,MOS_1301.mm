<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1538652043529" ID="ID_1537275495" MODIFIED="1539170236900" TEXT="Registration - Registration Checks">
<node COLOR="#33cc00" CREATED="1538652853212" HGAP="-46" ID="ID_1386135746" LINK="https://mosipid.atlassian.net/browse/MOS-558" MODIFIED="1542014768417" POSITION="right" TEXT="Packets Approval" VSHIFT="-179">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1538652868587" HGAP="26" ID="ID_49978482" MODIFIED="1539330145833" TEXT="Logged in as supervisor" VSHIFT="-105">
<edge COLOR="#00cc00"/>
<node COLOR="#33cc00" CREATED="1538652908178" ID="ID_392689235" MODIFIED="1539330145833" TEXT="Click &quot;Approve Registration&quot; tab">
<edge COLOR="#00cc00"/>
<node COLOR="#33cc00" CREATED="1538653455078" HGAP="-14" ID="ID_1677624651" MODIFIED="1539078703599" TEXT="Verify user is able to view the packets that are pending approval or on hold" VSHIFT="-16">
<node COLOR="#33cc00" CREATED="1539078127914" ID="ID_378219519" MODIFIED="1539078703599" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539078133981" ID="ID_900221249" MODIFIED="1539078703599" TEXT="Display the packets with appropriate state"/>
</node>
<node COLOR="#ff6600" CREATED="1539078138786" ID="ID_748249418" MODIFIED="1539330126316" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539078165781" ID="ID_1070544678" MODIFIED="1539330126312" TEXT="No packets pending approval">
<edge COLOR="#ff0000"/>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538653958864" HGAP="17" ID="ID_355379415" MODIFIED="1539078703599" TEXT="Changing the packets state" VSHIFT="-25">
<node COLOR="#33cc00" CREATED="1538654063817" ID="ID_768731951" MODIFIED="1539078703599" TEXT="Verify whether user is able to Approve">
<node COLOR="#33cc00" CREATED="1539078127914" ID="ID_225265098" MODIFIED="1539078703599" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539078133981" ID="ID_893581894" MODIFIED="1539078703599" TEXT="Set the packet status as mentioned"/>
</node>
<node COLOR="#ff6600" CREATED="1539078138786" ID="ID_1207972570" MODIFIED="1539330126316" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539329247495" ID="ID_1349599077" MODIFIED="1539329371624" TEXT="Display &quot;Appropriate error message&#x201d; / raise a defect">
<edge COLOR="#ff0000"/>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538654072086" ID="ID_1855230560" MODIFIED="1539078703599" TEXT="Verify whether user is able to Reject only with reasons">
<node COLOR="#33cc00" CREATED="1539078127914" ID="ID_1279158298" MODIFIED="1539078703599" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539078133981" ID="ID_26574399" MODIFIED="1539078703599" TEXT="Set the packet status as mentioned"/>
</node>
<node COLOR="#ff6600" CREATED="1539078138786" ID="ID_276866810" MODIFIED="1539330126316" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539329247495" ID="ID_3048361" MODIFIED="1539329371624" TEXT="Display &quot;Appropriate error message&#x201d; / raise a defect">
<edge COLOR="#ff0000"/>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538654075922" ID="ID_545153275" MODIFIED="1539078703599" TEXT="Verify whether user is able to hold a packet">
<node COLOR="#33cc00" CREATED="1539078127914" ID="ID_1255490345" MODIFIED="1539078703599" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539078133981" ID="ID_1828449595" MODIFIED="1539078703599" TEXT="Set the packet status as mentioned"/>
</node>
<node COLOR="#ff6600" CREATED="1539078138786" ID="ID_1253768757" MODIFIED="1539330126316" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539329247495" ID="ID_1339903798" MODIFIED="1539329371624" TEXT="Display &quot;Appropriate error message&#x201d; / raise a defect">
<edge COLOR="#ff0000"/>
</node>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538654131586" HGAP="24" ID="ID_317915972" MODIFIED="1539078703599" TEXT="Verify the same packet will not be displayed again in the queue once the status is changed" VSHIFT="-25">
<node COLOR="#33cc00" CREATED="1539078230569" ID="ID_1766639290" MODIFIED="1539078703599" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539078272128" ID="ID_571142084" MODIFIED="1539078703599" TEXT="The window must display only the packets that are pending approval"/>
</node>
<node COLOR="#ff6600" CREATED="1539078264533" ID="ID_57049868" MODIFIED="1539330126316" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539329247495" ID="ID_1642191612" MODIFIED="1539329371624" TEXT="Display &quot;Appropriate error message&#x201d; / raise a defect">
<edge COLOR="#ff0000"/>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538654292852" HGAP="13" ID="ID_1759712989" MODIFIED="1539078703599" TEXT="Verify rejected packets and the packets that have been put on hold should not appear in the approval list again" VSHIFT="28">
<node COLOR="#33cc00" CREATED="1539078230569" ID="ID_1475111846" MODIFIED="1539078703599" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539078272128" ID="ID_1986955552" MODIFIED="1539078703599" TEXT="The window must display only the packets that are pending approval"/>
</node>
<node COLOR="#ff6600" CREATED="1539078264533" ID="ID_627828181" MODIFIED="1539330126316" TEXT="No">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539329247495" ID="ID_592124478" MODIFIED="1539329371624" TEXT="Display &quot;Appropriate error message&#x201d; / raise a defect">
<edge COLOR="#ff0000"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#ff6600" CREATED="1538652914214" HGAP="115" ID="ID_1933601034" MODIFIED="1539330126336" TEXT="Logged in as other than supervisor" VSHIFT="-6">
<edge COLOR="#ff0000"/>
<node COLOR="#ff6600" CREATED="1538653044634" ID="ID_1659665533" MODIFIED="1539330128532" TEXT="Verify the tab &quot;Approve Registration&quot; is not enabled">
<edge COLOR="#ff0000"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="16" ID="ID_1167196337" MODIFIED="1539004933785" TEXT="Verification of Txn details for Audit purpose" VSHIFT="86">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_648252266" MODIFIED="1539330145833" TEXT="System capture all Txn details">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1079503882" MODIFIED="1539330145833" TEXT="Store all the details under &quot;Audit_Log&quot; table">
<edge COLOR="#00cc00"/>
</node>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1951538127" MODIFIED="1539330126336" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539329247495" ID="ID_1998323416" MODIFIED="1539329371624" TEXT="Display &quot;Appropriate error message&#x201d; / raise a defect">
<edge COLOR="#ff0000"/>
</node>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538653718564" HGAP="-33" ID="ID_1690506034" LINK="https://mosipid.atlassian.net/browse/MOS-559" MODIFIED="1546595906843" POSITION="left" TEXT="Push Packets" VSHIFT="-199">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1538654728159" HGAP="-40" ID="ID_467804914" MODIFIED="1539079059939" TEXT="Synced and approved packets" VSHIFT="-106">
<node COLOR="#33cc00" CREATED="1539078880973" ID="ID_1519573899" MODIFIED="1539079059939" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1538657876122" ID="ID_670390167" MODIFIED="1539079059939" TEXT="Verify packets are in zipped format">
<node COLOR="#33cc00" CREATED="1538658202665" HGAP="5" ID="ID_1523312499" MODIFIED="1539081311622" TEXT="Using third party tool" VSHIFT="-37">
<node COLOR="#33cc00" CREATED="1539079834054" ID="ID_659073149" MODIFIED="1539081311622" TEXT="FTP successful login with username and password">
<node COLOR="#33cc00" CREATED="1539080022300" ID="ID_1175169703" MODIFIED="1539081311622" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539080117641" ID="ID_1979814426" MODIFIED="1539081311622" TEXT="System will display the list of packet RIDs that have been synced to server and exported to the local folder but not yet pushed to server"/>
</node>
<node COLOR="#ff6600" CREATED="1539080031087" ID="ID_380828991" MODIFIED="1539081330631" TEXT="No">
<node COLOR="#ff0000" CREATED="1539080158060" ID="ID_7352849" MODIFIED="1540443817735" TEXT="Display appropriate error message"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539080050145" ID="ID_878673543" MODIFIED="1539081311622" TEXT="Verify user is able to choose to push packets to server">
<node COLOR="#33cc00" CREATED="1539080022300" ID="ID_1840105521" MODIFIED="1539081311622" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539080179768" ID="ID_880178018" MODIFIED="1539081311622" TEXT="The packets gets selected as per the user&apos;s choice"/>
</node>
<node COLOR="#ff6600" CREATED="1539080031087" ID="ID_1654099621" MODIFIED="1539081330616" TEXT="No">
<node COLOR="#ff0000" CREATED="1539080617969" ID="ID_628397598" MODIFIED="1539081351320" TEXT="Display no packets selected to push"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539080259434" ID="ID_839479398" MODIFIED="1539081311622" TEXT="Verify if user is able to select different source and destination folder">
<node COLOR="#33cc00" CREATED="1539080022300" ID="ID_1584411115" MODIFIED="1539081311622" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539080179768" ID="ID_1422001484" MODIFIED="1539081311622" TEXT="Display the folder as per the user&apos;s selection"/>
</node>
<node COLOR="#ff6600" CREATED="1539080031087" ID="ID_1608251856" MODIFIED="1539081330616" TEXT="No">
<node COLOR="#ff0000" CREATED="1539080158060" ID="ID_883469717" MODIFIED="1540443822521" TEXT="Display appropriate error message"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539080655620" ID="ID_1451028728" MODIFIED="1539081311622" TEXT="Verify the status of the packets gets changed after push">
<node COLOR="#33cc00" CREATED="1539080709848" ID="ID_1818482033" MODIFIED="1539081311622" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539081023473" ID="ID_884138881" MODIFIED="1539081311622" TEXT="Display the status as &quot;Pushed to server&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539080716112" ID="ID_409150919" MODIFIED="1539081330616" TEXT="No">
<node COLOR="#ff0000" CREATED="1539080158060" ID="ID_1479012286" MODIFIED="1540443822521" TEXT="Display appropriate error message"/>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538658202665" HGAP="13" ID="ID_1079973783" MODIFIED="1539081311622" TEXT="Using Upload portal" VSHIFT="-7">
<node COLOR="#33cc00" CREATED="1539080050145" ID="ID_418448049" MODIFIED="1539081311622" TEXT="Verify user is able to choose to push packets to server">
<node COLOR="#33cc00" CREATED="1539080022300" ID="ID_1478775423" MODIFIED="1539081311622" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539080179768" ID="ID_1677265622" MODIFIED="1539081311622" TEXT="The packets gets selected as per the user&apos;s choice"/>
</node>
<node COLOR="#ff6600" CREATED="1539080031087" ID="ID_1281333410" MODIFIED="1539081330616" TEXT="No">
<node COLOR="#ff0000" CREATED="1539080617969" ID="ID_1461605548" MODIFIED="1539081351320" TEXT="Display no packets selected to push"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539080259434" ID="ID_522383476" MODIFIED="1539081311622" TEXT="Verify if user is able to select different source and destination folder">
<node COLOR="#33cc00" CREATED="1539080022300" ID="ID_976045239" MODIFIED="1539081311622" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539080179768" ID="ID_1929315936" MODIFIED="1539081311622" TEXT="Display the folder as per the user&apos;s selection"/>
</node>
<node COLOR="#ff6600" CREATED="1539080031087" ID="ID_1842100622" MODIFIED="1540443837691" TEXT="No">
<node COLOR="#ff0000" CREATED="1539080158060" ID="ID_337104075" MODIFIED="1540443822521" TEXT="Display appropriate error message"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1539080655620" ID="ID_1768070476" MODIFIED="1539081311622" TEXT="Verify the status of the packets gets changed after push">
<node COLOR="#33cc00" CREATED="1539080709848" ID="ID_1978359480" MODIFIED="1539081311622" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1539081023473" ID="ID_1494658355" MODIFIED="1539081311622" TEXT="Display the status as &quot;Pushed to server&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1539080716112" ID="ID_1371644083" MODIFIED="1539081330616" TEXT="No">
<node COLOR="#ff0000" CREATED="1539080158060" ID="ID_581423107" MODIFIED="1540443822521" TEXT="Display appropriate error message"/>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1538658989916" HGAP="22" ID="ID_1553335284" MODIFIED="1539081311622" TEXT="Network issues while uploading" VSHIFT="29">
<node COLOR="#33cc00" CREATED="1539079316576" ID="ID_1248876516" MODIFIED="1539081311622" TEXT="No">
<node COLOR="#33cc00" CREATED="1539081190740" ID="ID_1454679505" MODIFIED="1539081311622" TEXT="Push the packets as per user choice"/>
</node>
<node COLOR="#ff6600" CREATED="1539081181146" ID="ID_1608941883" MODIFIED="1539081330616" TEXT="Yes">
<node COLOR="#ff0000" CREATED="1538659020322" ID="ID_331512891" MODIFIED="1540443843481" TEXT="Appropriate error message will be displayed"/>
</node>
</node>
</node>
</node>
<node COLOR="#ff6600" CREATED="1539078889940" ID="ID_1504377593" MODIFIED="1539078998828" TEXT="No">
<node COLOR="#ff6600" CREATED="1538657876122" ID="ID_462683657" MODIFIED="1539078998828" TEXT="Verify packets are in zipped format">
<node COLOR="#ff6600" CREATED="1538658202665" HGAP="5" ID="ID_1768875475" MODIFIED="1539078998828" TEXT="Using third party tool" VSHIFT="-37">
<node COLOR="#ff0000" CREATED="1538658342593" ID="ID_1404385570" MODIFIED="1539079012425" TEXT="Display &quot;The following packets were not pushed. Please sync the packets before attempting to push [List of RIDs which failed the sync check&quot;"/>
</node>
<node COLOR="#ff6600" CREATED="1538658221684" HGAP="12" ID="ID_653455788" MODIFIED="1539078998828" TEXT="Using upload portal" VSHIFT="33">
<node COLOR="#ff0000" CREATED="1538658342593" ID="ID_786122102" MODIFIED="1539079012425" TEXT="Display &quot;The following packets were not pushed. Please sync the packets before attempting to push [List of RIDs which failed the sync check&quot;"/>
</node>
</node>
</node>
</node>
<node COLOR="#ff6600" CREATED="1538658276634" HGAP="51" ID="ID_1955526336" MODIFIED="1539081362011" TEXT="No packets available to push" VSHIFT="-117">
<node COLOR="#ff0000" CREATED="1538658316324" ID="ID_318724559" MODIFIED="1539079045328" TEXT="Display &quot;No packets selected to push&quot;"/>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="45" ID="ID_697675290" MODIFIED="1539081358847" TEXT="Verification of Txn details for Audit purpose" VSHIFT="-19">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_1546632145" MODIFIED="1539060406447" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_259592844" MODIFIED="1539004902947" TEXT="Store all the details under &quot;Audit_Log&quot; table"/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1625172947" MODIFIED="1539060478963" TEXT="System fails to capture Txn details">
<node COLOR="#ff0000" CREATED="1539060455389" ID="ID_934288027" MODIFIED="1539060473076" TEXT="Display appropriate error message"/>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542009489833" HGAP="-9" ID="ID_247503030" LINK="https://mosipid.atlassian.net/browse/MOS-1315" MODIFIED="1542014777441" POSITION="right" TEXT="Preview Registration Details" VSHIFT="47">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1542014329542" ID="ID_1670888950" MODIFIED="1542014656508" TEXT="Click on &#x2018;Next&#x2019; after photo capture and verify preview page is displayed">
<node COLOR="#33cc00" CREATED="1542014380498" ID="ID_1540458702" MODIFIED="1542014656508" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1542014401385" ID="ID_343120382" MODIFIED="1542014750997" TEXT="Display the demographic details, document upload metadata, face photo and biometric details"/>
</node>
<node COLOR="#ff6600" CREATED="1542014384145" ID="ID_1273422794" MODIFIED="1542014665996" TEXT="No">
<node COLOR="#ff0000" CREATED="1542014405289" ID="ID_785309368" MODIFIED="1542014675905" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542014414793" ID="ID_1166972374" MODIFIED="1542014656506" TEXT="Verify the demographic , Biometric and document metadata are in read only mode">
<node COLOR="#33cc00" CREATED="1542014476161" ID="ID_1707626907" MODIFIED="1542014656507" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1542014496913" ID="ID_619552018" MODIFIED="1542014656508" TEXT="Validate the details"/>
</node>
<node COLOR="#ff6600" CREATED="1542014384145" ID="ID_1324391270" MODIFIED="1542014665996" TEXT="No">
<node COLOR="#ff0000" CREATED="1542014405289" ID="ID_920367361" MODIFIED="1542014675905" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1542014513337" ID="ID_1218846715" MODIFIED="1542014656507" TEXT="Verify &quot;Edit&quot; option helps to edit the details entered already">
<node COLOR="#33cc00" CREATED="1542014589000" ID="ID_980362319" MODIFIED="1542014656507" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1542014593032" ID="ID_1133490719" MODIFIED="1542014656507" TEXT="Edit the details as required"/>
</node>
<node COLOR="#ff6600" CREATED="1542014384145" ID="ID_1838798924" MODIFIED="1542014665995" TEXT="No">
<node COLOR="#ff0000" CREATED="1542014405289" ID="ID_1925099274" MODIFIED="1542014675904" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="112" ID="ID_1282327894" MODIFIED="1542005236742" TEXT="Verification of Txn details for Audit purpose" VSHIFT="19">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_548853522" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1086814999" MODIFIED="1542008615188" TEXT="Store all the details under &quot;Audit_Log&quot; table such as user id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1200248677" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_1008217879" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546595893003" HGAP="-18" ID="ID_1249893881" LINK="https://mosipid.atlassian.net/browse/MOS-1300" MODIFIED="1546597396258" POSITION="left" TEXT="MOS-1300" VSHIFT="43">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1546595942446" ID="ID_382807812" MODIFIED="1546596551326" TEXT="Local duplicate check for biometric">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1546596106689" HGAP="21" ID="ID_1423660699" MODIFIED="1551691922686" TEXT="RO fingerprint is captured instead of resident&apos;s and click continue" VSHIFT="-49">
<node COLOR="#33cc00" CREATED="1546596210271" ID="ID_1767460365" MODIFIED="1546596509283" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546596210271" ID="ID_1742632517" MODIFIED="1551691886864" TEXT="Display &quot;Display &quot;&lt;biometric1&gt; failed the local duplicate check!&quot; and user has to re-capture the resident&apos;s fingerprint based on the alert"/>
</node>
<node COLOR="#ff9900" CREATED="1546596210271" ID="ID_226389309" MODIFIED="1546596528986" TEXT="No">
<node COLOR="#ff0000" CREATED="1546596248503" ID="ID_781719933" MODIFIED="1551691900142" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546596305100" ID="ID_1574528390" MODIFIED="1546596509282" TEXT="Verify the retry count is set to zero and allow recapture of fingerprints when a duplicate is found.">
<node COLOR="#33cc00" CREATED="1546596210271" ID="ID_215941344" MODIFIED="1546596509282" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546596210271" ID="ID_1414825225" MODIFIED="1546596509281" TEXT="Proceed with recapture "/>
</node>
<node COLOR="#ff9900" CREATED="1546596210271" ID="ID_757065103" MODIFIED="1546596523748" TEXT="No">
<node COLOR="#ff0000" CREATED="1546596248503" ID="ID_1171508092" MODIFIED="1546596542885" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546596414762" HGAP="60" ID="ID_703499177" MODIFIED="1546596509281" TEXT="Verify fingerprint recapture attempts is not capped due to duplicate biometrics" VSHIFT="34">
<node COLOR="#33cc00" CREATED="1546596210271" ID="ID_300369736" MODIFIED="1546596509280" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546596210271" ID="ID_1699203649" MODIFIED="1546596509278" TEXT="Proceed with recapture "/>
</node>
<node COLOR="#ff9900" CREATED="1546596210271" ID="ID_105772794" MODIFIED="1546596523748" TEXT="No">
<node COLOR="#ff0000" CREATED="1546596248503" ID="ID_1090881465" MODIFIED="1546596542884" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="27" ID="ID_392708883" MODIFIED="1546596278548" TEXT="Verification of Txn details for Audit purpose" VSHIFT="47">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_308805736" MODIFIED="1539060406447" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1547899850" MODIFIED="1539004902947" TEXT="Store all the details under &quot;Audit_Log&quot; table"/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_881666931" MODIFIED="1539060478963" TEXT="System fails to capture Txn details">
<node COLOR="#ff0000" CREATED="1539060455389" ID="ID_1993063478" MODIFIED="1539060473076" TEXT="Display appropriate error message"/>
</node>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546602928339" HGAP="-94" ID="ID_910619671" LINK="https://mosipid.atlassian.net/browse/MOS-1301" MODIFIED="1546608174501" POSITION="right" TEXT="MOS-1301" VSHIFT="178">
<node COLOR="#33cc00" CREATED="1546606828836" HGAP="19" ID="ID_305699932" MODIFIED="1546608174501" TEXT="RO authenticates registration" VSHIFT="7">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1546606889260" HGAP="16" ID="ID_523330052" MODIFIED="1546846239484" TEXT="Verify system allows RO to retry unlimited number of times when credentials / OTP does not match DB in packet authentication screen" VSHIFT="-27">
<node COLOR="#33cc00" CREATED="1546606934546" ID="ID_265277750" MODIFIED="1546607809984" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546606946009" ID="ID_1277694782" MODIFIED="1546607809984" TEXT="Try with correct credentials"/>
</node>
<node COLOR="#ff9900" CREATED="1546606934546" ID="ID_1897973274" MODIFIED="1546607822113" TEXT="No">
<node COLOR="#ff3300" CREATED="1546606956952" ID="ID_1765670775" MODIFIED="1546607832045" TEXT="Display &quot;Authentication failed. Please try again&#x201d; and keeps on display the same screen till user provides a valid details"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546606987686" HGAP="12" ID="ID_1024981838" MODIFIED="1546607809984" TEXT="Verify system follows the same order for authentication when it is configured with multi factor authentication" VSHIFT="27">
<node COLOR="#33cc00" CREATED="1546606934546" ID="ID_738677456" MODIFIED="1546607809984" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546606946009" ID="ID_1071871962" MODIFIED="1546607809984" TEXT="Pass the correct value for each authentication"/>
</node>
<node COLOR="#ff9900" CREATED="1546606934546" ID="ID_1163667587" MODIFIED="1546607822113" TEXT="No">
<node COLOR="#ff3300" CREATED="1546606956952" ID="ID_744108366" MODIFIED="1546607832045" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546607337032" HGAP="18" ID="ID_358167816" MODIFIED="1546607809984" TEXT="System validation for diff authentication mode" VSHIFT="44">
<node COLOR="#33cc00" CREATED="1546607415566" HGAP="11" ID="ID_823070627" MODIFIED="1546607809984" TEXT="Biometrics" VSHIFT="-23">
<node COLOR="#33cc00" CREATED="1546607434471" ID="ID_128169205" MODIFIED="1546607809984" TEXT="Threshold value met">
<node COLOR="#33cc00" CREATED="1546606934546" ID="ID_372875665" MODIFIED="1546607809984" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546607495161" ID="ID_1683884868" MODIFIED="1546607809984" TEXT="Display the next page in the flow as configured"/>
</node>
<node COLOR="#ff9900" CREATED="1546606934546" ID="ID_1839299438" MODIFIED="1546607822113" TEXT="No">
<node COLOR="#ff3300" CREATED="1546606956952" ID="ID_1811681919" MODIFIED="1546607832045" TEXT="Retry with Biometric detail"/>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546607447842" ID="ID_1556639152" MODIFIED="1546607809984" TEXT="OTP">
<node COLOR="#33cc00" CREATED="1546607461748" ID="ID_1298686959" MODIFIED="1546607809984" TEXT="Compare with server">
<node COLOR="#33cc00" CREATED="1546607475050" ID="ID_1111428489" MODIFIED="1546607809984" TEXT="Matches">
<node COLOR="#33cc00" CREATED="1546607495161" ID="ID_143075870" MODIFIED="1546607809984" TEXT="Display the next page in the flow as configured"/>
</node>
<node COLOR="#ff9900" CREATED="1546607484107" ID="ID_1778847090" MODIFIED="1546607822113" TEXT="Does not match">
<node COLOR="#ff3300" CREATED="1546606956952" ID="ID_597918069" MODIFIED="1546607832045" TEXT="Display &quot;Authentication failed. Please try again&#x201d;"/>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546607630440" HGAP="14" ID="ID_891139442" MODIFIED="1546607809984" TEXT="Password" VSHIFT="30">
<node COLOR="#33cc00" CREATED="1546607643788" ID="ID_638608147" MODIFIED="1546607809984" TEXT="Compare with CB">
<node COLOR="#33cc00" CREATED="1546607475050" ID="ID_1710315683" MODIFIED="1546607809984" TEXT="Matches">
<node COLOR="#33cc00" CREATED="1546607495161" ID="ID_669140531" MODIFIED="1546607809984" TEXT="Display the next page in the flow as configured"/>
</node>
<node COLOR="#ff9900" CREATED="1546607484107" ID="ID_1146136082" MODIFIED="1546607822113" TEXT="Does not match">
<node COLOR="#ff3300" CREATED="1546606956952" ID="ID_58571125" MODIFIED="1546607832045" TEXT="Display &quot;Authentication failed. Please try again&#x201d;"/>
</node>
</node>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="24" ID="ID_250338181" MODIFIED="1546846020193" TEXT="Verification of Txn details for Audit purpose" VSHIFT="33">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_287668646" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1301409078" MODIFIED="1542008615188" TEXT="Store all the details under &quot;Audit_Log&quot; table such as user id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_68831302" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_983213955" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</node>
</map>
