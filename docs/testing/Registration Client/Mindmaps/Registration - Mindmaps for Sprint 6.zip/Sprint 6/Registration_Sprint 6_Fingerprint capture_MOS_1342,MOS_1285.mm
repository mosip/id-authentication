<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1546520864989" ID="ID_1317859420" MODIFIED="1551690748400" TEXT="Registration - Fingerprint / IRIScapture">
<node CREATED="1546520973351" ID="ID_522671712" LINK="https://mosipid.atlassian.net/browse/MOS-1342" MODIFIED="1546521616386" POSITION="right" TEXT="MOS-1342">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1546521001526" HGAP="13" ID="ID_1968386803" MODIFIED="1546521891168" TEXT="Verify the user is able to capture the fingerprint in any order" VSHIFT="-31">
<node COLOR="#33cc00" CREATED="1546521022760" ID="ID_982081146" MODIFIED="1546521891168" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546521034362" ID="ID_386837256" MODIFIED="1546521891168" TEXT="Capture left slap, right slap and both thumb in any order"/>
</node>
<node COLOR="#ff6600" CREATED="1546521027700" ID="ID_383504630" MODIFIED="1546521908080" TEXT="No">
<node COLOR="#ff0000" CREATED="1546521056445" ID="ID_1272153836" MODIFIED="1546521929016" TEXT="Verify the device is onboarded">
<node COLOR="#ff6600" CREATED="1546521067298" ID="ID_1023084735" MODIFIED="1546521908080" TEXT="Yes">
<node COLOR="#ff0000" CREATED="1546521088435" ID="ID_436283857" MODIFIED="1546521929016" TEXT="Raise a defect"/>
</node>
<node COLOR="#33cc00" CREATED="1546521072085" ID="ID_1733658375" MODIFIED="1546521891168" TEXT="No">
<node COLOR="#33cc00" CREATED="1546521076007" ID="ID_1865527747" MODIFIED="1546521891168" TEXT="On-board the device and then re-try"/>
</node>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546521103581" ID="ID_470158073" MODIFIED="1551689843862" TEXT="Verify the threshold score for each capture.">
<node COLOR="#33cc00" CREATED="1546521124228" ID="ID_596887449" MODIFIED="1546521891168" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546521140974" ID="ID_710991103" MODIFIED="1551689634692" TEXT="Verify the threshold score matches the config value"/>
</node>
<node COLOR="#ff6600" CREATED="1546521129983" ID="ID_1680947325" MODIFIED="1546521908080" TEXT="No">
<node COLOR="#ff0000" CREATED="1546521133954" ID="ID_485744719" MODIFIED="1546521929016" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546521166767" HGAP="15" ID="ID_1900058499" MODIFIED="1546521891168" TEXT="Verify the system recommends the user to re-capture the finger if the quality score is not met" VSHIFT="41">
<node COLOR="#33cc00" CREATED="1546521124228" ID="ID_1390732079" MODIFIED="1546521891168" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546521140974" ID="ID_1227803039" MODIFIED="1546521891168" TEXT="Retry up to maximum limit"/>
</node>
<node COLOR="#ff6600" CREATED="1546521129983" ID="ID_1970666755" MODIFIED="1546521908080" TEXT="No">
<node COLOR="#ff0000" CREATED="1546521133954" ID="ID_1868599319" MODIFIED="1546521929016" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33ff00" CREATED="1551690391376" HGAP="21" ID="ID_979550364" MODIFIED="1551690713307" TEXT="Behavior of quality indicator" VSHIFT="20">
<node COLOR="#ff3300" CREATED="1551690417877" ID="ID_940877786" MODIFIED="1551690510896" TEXT="&lt;Threshold">
<node COLOR="#ff0000" CREATED="1551690443863" ID="ID_1450862677" MODIFIED="1551690527299" TEXT="Both score and attempts should display in Red"/>
</node>
<node COLOR="#33ff00" CREATED="1551690422937" ID="ID_1433208792" MODIFIED="1551690491028" TEXT="&gt;= Threshold">
<node COLOR="#33ff00" CREATED="1551690443863" ID="ID_1048896103" MODIFIED="1551690491028" TEXT="Both score and attempts should display in Green"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546521258236" ID="ID_1328461748" MODIFIED="1546521891168" TEXT="Behavior of earlier quality score and quality indicator when user retries to capture" VSHIFT="27">
<node COLOR="#33cc00" CREATED="1546521324801" ID="ID_747340334" MODIFIED="1551690380136" TEXT="The earlier quality score and quality indicator should be replaced by the current quality score on screen."/>
</node>
<node COLOR="#33cc00" CREATED="1546521414772" HGAP="21" ID="ID_1643776766" MODIFIED="1546521891168" TEXT="Verify RC displays alert message when max attempt is exceeded" VSHIFT="46">
<node COLOR="#33cc00" CREATED="1546521124228" ID="ID_930297638" MODIFIED="1546521891168" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546521140974" ID="ID_498222363" MODIFIED="1546522717279" TEXT="Display &#x201c;You have reached the maximum number of retries.&#x201d;"/>
</node>
<node COLOR="#ff6600" CREATED="1546521129983" ID="ID_1029087535" MODIFIED="1546521908080" TEXT="No">
<node COLOR="#ff0000" CREATED="1546521133954" ID="ID_996751796" MODIFIED="1546521929016" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546521488455" ID="ID_1033837174" MODIFIED="1551689756319" TEXT="Verify the system determines and displays rank for each finger in ack">
<node COLOR="#33cc00" CREATED="1546521124228" ID="ID_578041283" MODIFIED="1546521891152" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546521140974" ID="ID_1808424951" MODIFIED="1546521891152" TEXT="The finger with the highest quality score is ranked 1 and so on till 10 (excluding exceptions)."/>
</node>
<node COLOR="#ff6600" CREATED="1546521129983" ID="ID_1127554874" MODIFIED="1546521908080" TEXT="No">
<node COLOR="#ff0000" CREATED="1546521133954" ID="ID_260311366" MODIFIED="1546521929016" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546521533828" ID="ID_1001296623" MODIFIED="1546521891152" TEXT="Behavior of RC when two fingers have same score">
<node COLOR="#33cc00" CREATED="1546521567635" ID="ID_991715813" MODIFIED="1546521891152" TEXT="Display the same ranking for both. For example two fingers can be ranked 1. Then the next highest score finger will be ranked 2."/>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="9" ID="ID_1021783307" MODIFIED="1546498495098" TEXT="Verification of Txn details for Audit purpose" VSHIFT="34">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_163075645" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1629456931" MODIFIED="1546498515692" TEXT="Store all the details under &quot;Audit_Log&quot; table such as User id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1191661596" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_795182154" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
<node CREATED="1546520973351" ID="ID_1784208957" LINK="https://mosipid.atlassian.net/browse/MOS-1285" MODIFIED="1546522030123" POSITION="left" TEXT="MOS-1285">
<edge COLOR="#33cc00"/>
<node COLOR="#33cc00" CREATED="1546521001526" HGAP="13" ID="ID_937612189" MODIFIED="1546522046685" TEXT="Verify the user is able to capture the IRISes in any order" VSHIFT="-31">
<node COLOR="#33cc00" CREATED="1546521022760" ID="ID_1364465815" MODIFIED="1546521891168" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546521034362" ID="ID_678810577" MODIFIED="1546522066421" TEXT="Capture left  or right iris in any order"/>
</node>
<node COLOR="#ff6600" CREATED="1546521027700" ID="ID_1341400904" MODIFIED="1546521908080" TEXT="No">
<node COLOR="#ff0000" CREATED="1546521056445" ID="ID_230780624" MODIFIED="1546521929016" TEXT="Verify the device is onboarded">
<node COLOR="#ff6600" CREATED="1546521067298" ID="ID_240760434" MODIFIED="1546521908080" TEXT="Yes">
<node COLOR="#ff0000" CREATED="1546521088435" ID="ID_434737501" MODIFIED="1546521929016" TEXT="Raise a defect"/>
</node>
<node COLOR="#33cc00" CREATED="1546521072085" ID="ID_1939856468" MODIFIED="1546521891168" TEXT="No">
<node COLOR="#33cc00" CREATED="1546521076007" ID="ID_1091935777" MODIFIED="1546521891168" TEXT="On-board the device and then re-try"/>
</node>
</node>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546521103581" ID="ID_1516204783" MODIFIED="1546521891168" TEXT="Verify the quality score and the threshold score for each capture.">
<node COLOR="#33cc00" CREATED="1546521124228" ID="ID_1034056132" MODIFIED="1546521891168" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546521140974" ID="ID_1438157272" MODIFIED="1546521891168" TEXT="Verify the score matches the config value"/>
</node>
<node COLOR="#ff6600" CREATED="1546521129983" ID="ID_157838786" MODIFIED="1546521908080" TEXT="No">
<node COLOR="#ff0000" CREATED="1546521133954" ID="ID_938723594" MODIFIED="1546521929016" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546521166767" HGAP="15" ID="ID_1248846368" MODIFIED="1551690694456" TEXT="Verify the system recommends the user to re-capture the iris if the quality score is not met" VSHIFT="41">
<node COLOR="#33cc00" CREATED="1546521124228" ID="ID_79531842" MODIFIED="1546521891168" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546521140974" ID="ID_1313623769" MODIFIED="1546521891168" TEXT="Retry up to maximum limit"/>
</node>
<node COLOR="#ff6600" CREATED="1546521129983" ID="ID_1716506681" MODIFIED="1546521908080" TEXT="No">
<node COLOR="#ff0000" CREATED="1546521133954" ID="ID_1153863001" MODIFIED="1546521929016" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546521258236" ID="ID_1882710038" MODIFIED="1546521891168" TEXT="Behavior of earlier quality score and quality indicator when user retries to capture" VSHIFT="27">
<node COLOR="#33cc00" CREATED="1546521324801" ID="ID_173498682" MODIFIED="1546521891168" TEXT="The earlier quality score and quality indicator should be replaced by the current quality score on screen."/>
</node>
<node COLOR="#33ff00" CREATED="1551690391376" HGAP="21" ID="ID_1773799364" MODIFIED="1551690763338" TEXT="Behavior of quality indicator" VSHIFT="20">
<node COLOR="#ff3300" CREATED="1551690417877" ID="ID_489336357" MODIFIED="1551690510896" TEXT="&lt;Threshold">
<node COLOR="#ff0000" CREATED="1551690443863" ID="ID_1385858624" MODIFIED="1551690527299" TEXT="Both score and attempts should display in Red"/>
</node>
<node COLOR="#33ff00" CREATED="1551690422937" ID="ID_677810783" MODIFIED="1551690491028" TEXT="&gt;= Threshold">
<node COLOR="#33ff00" CREATED="1551690443863" ID="ID_554398845" MODIFIED="1551690491028" TEXT="Both score and attempts should display in Green"/>
</node>
</node>
<node COLOR="#33cc00" CREATED="1546521414772" HGAP="21" ID="ID_1182728092" MODIFIED="1546522575711" TEXT="Verify RC displays alert message when max attempt is exceeded / quality score is &gt;= threshold." VSHIFT="46">
<node COLOR="#33cc00" CREATED="1546521124228" ID="ID_1698002701" MODIFIED="1546521891168" TEXT="Yes">
<node COLOR="#33cc00" CREATED="1546521140974" ID="ID_1767602654" MODIFIED="1546522704815" TEXT="Display &#x201c;You have reached the maximum number of retries.&#x201d;"/>
</node>
<node COLOR="#ff6600" CREATED="1546521129983" ID="ID_770892" MODIFIED="1546521908080" TEXT="No">
<node COLOR="#ff0000" CREATED="1546521133954" ID="ID_541154317" MODIFIED="1546521929016" TEXT="Raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="9" ID="ID_1500230784" MODIFIED="1546498495098" TEXT="Verification of Txn details for Audit purpose" VSHIFT="34">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_484734182" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1029937259" MODIFIED="1546498515692" TEXT="Store all the details under &quot;Audit_Log&quot; table such as User id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_88350292" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_826094807" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</map>
