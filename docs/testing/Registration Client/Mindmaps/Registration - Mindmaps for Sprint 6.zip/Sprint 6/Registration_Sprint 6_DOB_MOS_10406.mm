<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1546514941245" ID="ID_1913957075" MODIFIED="1546514962113" TEXT="Registration - DOB when age is given">
<node CREATED="1546514966592" ID="ID_145948732" LINK="https://mosipid.atlassian.net/browse/MOS-10406" MODIFIED="1546517661307" POSITION="right" TEXT="MOS-10406">
<edge COLOR="#33ff00"/>
<node COLOR="#33ff00" CREATED="1546514987711" ID="ID_1789768461" MODIFIED="1546517673304" TEXT="Verify  system should default the date of birth to 1-1-year of birth when age is entered">
<node COLOR="#33ff00" CREATED="1546517600138" ID="ID_1153383972" MODIFIED="1546517673304" TEXT="Yes">
<node COLOR="#33ff00" CREATED="1546517616962" ID="ID_1703339991" MODIFIED="1546517673304" TEXT="Proceed with other fields "/>
</node>
<node COLOR="#ff9900" CREATED="1546517606340" ID="ID_1570275651" MODIFIED="1546517680253" TEXT="No">
<node COLOR="#ff0000" CREATED="1546517640745" ID="ID_1801404321" MODIFIED="1546517686057" TEXT="Display error message / Raise a defect"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="9" ID="ID_1021783307" MODIFIED="1546498495098" TEXT="Verification of Txn details for Audit purpose" VSHIFT="34">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_163075645" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1629456931" MODIFIED="1546498515692" TEXT="Store all the details under &quot;Audit_Log&quot; table such as User id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1191661596" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_795182154" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</map>
