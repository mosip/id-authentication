<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1546511429984" ID="ID_1258114739" MODIFIED="1546511486073" TEXT="Registration - Master Data syncher">
<node CREATED="1546511542960" ID="ID_1393232118" MODIFIED="1546513790286" POSITION="right" TEXT="Sync Master data with data store">
<edge COLOR="#00cc00"/>
<node CREATED="1546511567659" ID="ID_375451146" LINK="https://mosipid.atlassian.net/browse/MOS-1235" MODIFIED="1546511583945" TEXT="MOS-1235">
<node COLOR="#00cc00" CREATED="1546511644906" HGAP="4" ID="ID_805431123" MODIFIED="1546513948236" TEXT="Verify RC allows the user to send sync data request" VSHIFT="-27">
<node COLOR="#00cc00" CREATED="1546511670537" HGAP="17" ID="ID_1411179247" MODIFIED="1546513948236" TEXT="Scheduled" VSHIFT="-27">
<node COLOR="#00cc00" CREATED="1546511678659" HGAP="18" ID="ID_185048801" MODIFIED="1546513948235" TEXT="Yes" VSHIFT="-24">
<node COLOR="#00cc00" CREATED="1546511845038" ID="ID_696253761" MODIFIED="1546513948235" TEXT="Sync request should be sent as scheduled to server for master data sync"/>
</node>
<node COLOR="#00cc00" CREATED="1546511705926" ID="ID_1455155737" MODIFIED="1546513948235" TEXT="No">
<node COLOR="#00cc00" CREATED="1546511711495" ID="ID_184302647" MODIFIED="1546513948235" TEXT="Check the client is up and running">
<node COLOR="#00cc00" CREATED="1546511678659" ID="ID_1718376406" MODIFIED="1546513948235" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1546511797367" ID="ID_94651022" MODIFIED="1546513948234" TEXT="Display &#x201c;You must be connected to the internet to sync data.&#x201d;"/>
</node>
<node COLOR="#ff6600" CREATED="1546511705926" ID="ID_1464300702" MODIFIED="1546513968028" TEXT="No">
<node COLOR="#ff0000" CREATED="1546511771301" ID="ID_1387343892" MODIFIED="1546513988704" TEXT="Launch the application and connect to internet"/>
</node>
</node>
</node>
</node>
<node COLOR="#00cc00" CREATED="1546511683198" HGAP="24" ID="ID_428683583" MODIFIED="1546513948234" TEXT="Manual" VSHIFT="35">
<node COLOR="#00cc00" CREATED="1546511678659" HGAP="21" ID="ID_1951445205" MODIFIED="1546513948234" TEXT="Yes" VSHIFT="-21">
<node COLOR="#00cc00" CREATED="1546511928883" ID="ID_1145651150" MODIFIED="1546513948234" TEXT="Sync request should be sent to server for master data sync"/>
</node>
<node COLOR="#00cc00" CREATED="1546511705926" ID="ID_1092767317" MODIFIED="1546513948236" TEXT="No">
<node COLOR="#00cc00" CREATED="1546511711495" ID="ID_1433242561" MODIFIED="1546513948234" TEXT="Check the client is up and running and online">
<node COLOR="#00cc00" CREATED="1546511678659" ID="ID_1062897209" MODIFIED="1546513948233" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1546511797367" ID="ID_1050932167" MODIFIED="1546513948233" TEXT="Display &#x201c;You must be connected to the internet to sync data.&#x201d;"/>
</node>
<node COLOR="#ff6600" CREATED="1546511705926" ID="ID_1916005897" MODIFIED="1546513968028" TEXT="No">
<node COLOR="#ff0000" CREATED="1546511771301" ID="ID_823807204" MODIFIED="1546513988704" TEXT="Launch the application and connect to internet"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#00cc00" CREATED="1546511989761" HGAP="11" ID="ID_780637345" MODIFIED="1546513948233" TEXT="Verify whether RC receives a response for the request sent" VSHIFT="-45">
<node COLOR="#00cc00" CREATED="1546512388671" ID="ID_1017304903" MODIFIED="1546513948233" TEXT="Yes">
<node COLOR="#00cc00" CREATED="1546512423427" ID="ID_1298271934" MODIFIED="1546513948230" TEXT="Only the incremental changes (additions, deletions and modifications) made since the last sync should be received."/>
<node COLOR="#00cc00" CREATED="1546512956729" ID="ID_1484457083" MODIFIED="1546513948226" TEXT="Machine related master data should be received only for the specific machine from which request is initiated."/>
<node COLOR="#00cc00" CREATED="1546512974344" ID="ID_1233809683" MODIFIED="1546513948223" TEXT="Registration Centre related data should be received only for the specific Registration Centre mapped to the machine from which request is initiated"/>
<node COLOR="#00cc00" CREATED="1546512981294" ID="ID_1894943126" MODIFIED="1546513997932" TEXT="Device related data should be received only for devices mapped to the same Registration Centre as the machine from which request is initiated."/>
<node COLOR="#00cc00" CREATED="1546512989244" ID="ID_510974877" MODIFIED="1546513948220" TEXT="Supervisor and Officer related data should be received only for those users mapped to the same Registration Centre as the machine from which request is initiated"/>
</node>
<node COLOR="#ff6600" CREATED="1546512404218" ID="ID_413250447" MODIFIED="1546513968029" TEXT="No">
<node COLOR="#ff0000" CREATED="1546511797367" ID="ID_256788422" MODIFIED="1546513988704" TEXT="Display appropriate error message"/>
</node>
</node>
<node COLOR="#ff6600" CREATED="1546512559848" ID="ID_958917305" MODIFIED="1546513968029" TEXT="Sync failure">
<node COLOR="#ff6600" CREATED="1546512693165" ID="ID_251228526" MODIFIED="1546513968029" TEXT="Yes">
<node COLOR="#ff0000" CREATED="1546512661355" ID="ID_871721761" MODIFIED="1546513988703" TEXT="Display &quot;Sync Failure&quot; error message"/>
<node COLOR="#ff0000" CREATED="1546512715364" ID="ID_1077846249" MODIFIED="1546513988703" TEXT="Detailed errors can be viewed in the transaction logs."/>
</node>
<node COLOR="#33cc00" CREATED="1551690937648" ID="ID_71649863" MODIFIED="1551690987618" TEXT="No">
<node COLOR="#33cc00" CREATED="1551690960965" ID="ID_1587907896" MODIFIED="1551690987618" TEXT="Display &quot;Sync Success&quot; message"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1546512739929" HGAP="9" ID="ID_1515494922" MODIFIED="1546513948220" TEXT="End user able to perform other action when sync is running" VSHIFT="26">
<node COLOR="#ff6600" CREATED="1546512754387" ID="ID_720860815" MODIFIED="1546513968029" TEXT="Yes">
<node COLOR="#ff0000" CREATED="1546512772169" ID="ID_45526298" MODIFIED="1546513988703" TEXT="Display error message / Raise a defect"/>
</node>
<node COLOR="#00cc00" CREATED="1546512808301" ID="ID_155994106" MODIFIED="1546513948220" TEXT="No">
<node COLOR="#00cc00" CREATED="1546512827907" ID="ID_1159198216" MODIFIED="1546517537946" TEXT="Verify whether the UI displays the status of the sync"/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1546513016723" HGAP="14" ID="ID_1832477793" MODIFIED="1546513948220" TEXT="Behavior of scheduled sync" VSHIFT="34">
<node COLOR="#00cc00" CREATED="1546513047164" HGAP="17" ID="ID_181515142" MODIFIED="1546513948220" TEXT="Online" VSHIFT="-20">
<node COLOR="#00cc00" CREATED="1546511845038" ID="ID_1620851675" MODIFIED="1546517537946" TEXT="Sync request should be sent as scheduled to server for master data sync"/>
</node>
<node COLOR="#ff6600" CREATED="1546513054638" HGAP="18" ID="ID_448364924" MODIFIED="1546513968029" TEXT="Offline" VSHIFT="29">
<node COLOR="#ff0000" CREATED="1546513391885" ID="ID_265186527" MODIFIED="1546513988701" TEXT="The sync should be queued up and executed later. When the client is next launched and is online, check if the previous scheduled sync was executed. If not executed earlier, immediately start the sync."/>
</node>
</node>
<node COLOR="#00cc00" CREATED="1538550071542" HGAP="9" ID="ID_1021783307" MODIFIED="1546498495098" TEXT="Verification of Txn details for Audit purpose" VSHIFT="34">
<edge COLOR="#00cc00"/>
<node COLOR="#00cc00" CREATED="1539003087723" ID="ID_163075645" MODIFIED="1542005044938" TEXT="System capture all Txn details">
<node COLOR="#00cc00" CREATED="1539003122483" ID="ID_1629456931" MODIFIED="1546498515692" TEXT="Store all the details under &quot;Audit_Log&quot; table such as User id or system account; Machine Details; Event Name; Application Name, and Event data including user entered fields."/>
</node>
<node COLOR="#ff0000" CREATED="1539060442854" ID="ID_1191661596" MODIFIED="1542005044938" TEXT="System fails to capture Txn details">
<edge COLOR="#ff0000"/>
<node COLOR="#ff0000" CREATED="1539089688847" ID="ID_795182154" MODIFIED="1542005044938" TEXT="Display appropriate error message / Raise a defect"/>
</node>
</node>
</node>
</node>
</node>
</map>
